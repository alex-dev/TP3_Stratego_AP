#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include <Fl/Fl_Window.H>
#include <Fl/Fl_Box.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Round_Button.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Multiline_Output.H>
#include <FL/Fl_Check_Button.H>
#include "myGlWindow.h"

class gameEngine{
private:
	Fl_Window *w;
	Fl_Multiline_Output *output;
	CPU *computer;
	CPU *computer2;
	random_bot *rand_bot;
	one_ply_bot *one_bot;
	Fl_Button *playGame;
	Fl_Button *computerPlay;
	Fl_Button *randomPlay;
	Fl_Button *onePlay;
	Fl_Check_Button *setup_board;
	Fl_Box *title;
	Fl_Box *name;
	Fl_Round_Button *Flag_Button;
	Fl_Round_Button *Marshal_Button;
	Fl_Round_Button *General_Button;
	Fl_Round_Button *Colonel_Button;
	Fl_Round_Button *Major_Button;
	Fl_Round_Button *Captain_Button;
	Fl_Round_Button *Lieutenant_Button;
	Fl_Round_Button *Sergeant_Button;
	Fl_Round_Button *Miner_Button;
	Fl_Round_Button *Scout_Button;
	Fl_Round_Button *Spy_Button;
	Fl_Round_Button *Bomb_Button;
	Fl_Group *radio_buttons;
public:
	myGlWindow *g;
	gameEngine(myGlWindow *g, Fl_Window *w, CPU *computer, CPU *computer2, random_bot *rand_bot, one_ply_bot *one_bot);
	~gameEngine();
	bool place_player_piece(int index, int x_coord, int y_coord);
	bool place_AI_piece(int index, int x_coord, int y_coord);
	friend void playCB(Fl_Button* button, gameEngine *engine);
	friend void computerCB(Fl_Button* computerPlay, gameEngine *engine);
	friend void randomCB(Fl_Button* randomPlay, gameEngine *engine);
	friend void onePlayCB(Fl_Button* onePlay, gameEngine *engine);
	friend void flagCB(Fl_Round_Button* Flag_Button, gameEngine *engine);
	friend void marshalCB(Fl_Round_Button* Marshal_Button, gameEngine *engine);
	friend void generalCB(Fl_Round_Button* General_Button, gameEngine *engine);
	friend void colonelCB(Fl_Round_Button *Colonel_Button, gameEngine *engine);
	friend void majorCB(Fl_Round_Button *Major_Button, gameEngine *engine);
	friend void captainCB(Fl_Round_Button *Captain_Button, gameEngine *engine);
	friend void lieutenantCB(Fl_Round_Button *Lieutenant_Button, gameEngine *engine);
	friend void sergeantCB(Fl_Round_Button *Sergeant_Button, gameEngine *engine);
	friend void minerCB(Fl_Round_Button *Miner_Button, gameEngine *engine);
	friend void scoutCB(Fl_Round_Button *Scout_Button, gameEngine *engine);
	friend void spyCB(Fl_Round_Button *Spy_Button, gameEngine *engine);
	friend void bombCB(Fl_Round_Button *Bomb_Button, gameEngine *engine);
};

#endif