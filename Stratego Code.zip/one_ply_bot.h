#ifndef ONE_PLY_BOT_H
#define ONT_PLY_BOT_H

#include "gamePiece.h"

struct omoves
{
  int possible_moves[19][2];
};


class one_ply_bot{
private:
	gamePiece *board[10][10];
	gamePiece *myPieces[40];
	gamePiece *opponentPieces[40];
	bool known[40];
	int known_values[40];
	int board_piece_mappings[10][10];
	int probabilities[40][12][2];
	bool top;
	int pieces_left;
	int num_left[12];
	int move_count;
	int all_moves[40][10][10];
public:
	one_ply_bot(bool top);
	~one_ply_bot();
	void reset();
	gamePiece ** place_pieces();
	void make_move(int& x_from, int& y_from, int& x_to, int& y_to);
	void update_board(int x_from, int y_from, int x_to, int y_to, int collision_state, piece_type move_piece, piece_type collision_piece);
};

#endif