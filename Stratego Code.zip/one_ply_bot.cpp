#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "one_ply_bot.h"

one_ply_bot::one_ply_bot(bool top){
	int x;
	move_count=0;
	pieces_left=40;
	num_left[0]=1;
	num_left[1]=1;
	num_left[2]=1;
	num_left[3]=2;
	num_left[4]=3;
	num_left[5]=4;
	num_left[6]=4;
	num_left[7]=4;
	num_left[8]=5;
	num_left[9]=8;
	num_left[10]=1;
	num_left[11]=6;
	this->top = top;
	for(x=0; x<10; x++){
		for(int y=0; y<10; y++){
			board[x][y]=NULL;
			board_piece_mappings[x][y]=-1;
		}
	}
	myPieces[0]=new gamePiece(Marshal, AI);
	myPieces[1]=new gamePiece(General, AI);
	for(x=2; x<=3; x++){
		myPieces[x]=new gamePiece(Colonel, AI);
	}
	for(x=4; x<=6; x++){
		myPieces[x]=new gamePiece(Major, AI);
	}
	for(x=7; x<=10; x++){
		myPieces[x]=new gamePiece(Captain, AI);
	}
	for(x=11; x<=14; x++){
		myPieces[x]=new gamePiece(Lieutenant, AI);
	}
	for(x=15; x<=18; x++){
		myPieces[x]=new gamePiece(Sergeant, AI);
	}
	for(x=19; x<=23; x++){
		myPieces[x]=new gamePiece(Miner, AI);
	}
	for(x=24; x<=31; x++){
		myPieces[x]=new gamePiece(Scout, AI);
	}
	myPieces[32]=new gamePiece(Spy, AI);
	for(x=33; x<=38; x++){
		myPieces[x]=new gamePiece(Bomb, AI);
	}
	myPieces[39]=new gamePiece(Flag, AI);
	for(x=0; x<40; x++){
		known[x]=false;
		known_values[x]=999;
		opponentPieces[x]=new gamePiece(Blank, User);
		probabilities[x][0][0]=1;
		probabilities[x][0][1]=40;
		probabilities[x][1][0]=1;
		probabilities[x][1][1]=40;
		probabilities[x][2][0]=1;
		probabilities[x][2][1]=40;
		probabilities[x][3][0]=2;
		probabilities[x][3][1]=40;
		probabilities[x][4][0]=3;
		probabilities[x][4][1]=40;
		probabilities[x][5][0]=4;
		probabilities[x][5][1]=40;
		probabilities[x][6][0]=4;
		probabilities[x][6][1]=40;
		probabilities[x][7][0]=4;
		probabilities[x][7][1]=40;
		probabilities[x][8][0]=5;
		probabilities[x][8][1]=40;
		probabilities[x][9][0]=8;
		probabilities[x][9][1]=40;
		probabilities[x][10][0]=1;
		probabilities[x][10][1]=40;
		probabilities[x][11][0]=6;
		probabilities[x][11][1]=40;
		for(int i=0; i<10; i++){
			for(int j=0; j<10; j++){
				all_moves[x][i][j]=0;
			}
		}
	}
}

void one_ply_bot::reset(){
	int x;
	move_count=0;
	pieces_left=40;
	num_left[0]=1;
	num_left[1]=1;
	num_left[2]=1;
	num_left[3]=2;
	num_left[4]=3;
	num_left[5]=4;
	num_left[6]=4;
	num_left[7]=4;
	num_left[8]=5;
	num_left[9]=8;
	num_left[10]=1;
	num_left[11]=6;
	for(x=0; x<10; x++){
		for(int y=0; y<10; y++){
			board[x][y]=NULL;
			board_piece_mappings[x][y]=-1;
		}
	}
	for(x=0; x<40; x++){
		known[x]=false;
		known_values[x]=999;
		myPieces[x]->update_coordinates(-1, -1);
		probabilities[x][0][0]=1;
		probabilities[x][0][1]=40;
		probabilities[x][1][0]=1;
		probabilities[x][1][1]=40;
		probabilities[x][2][0]=1;
		probabilities[x][2][1]=40;
		probabilities[x][3][0]=2;
		probabilities[x][3][1]=40;
		probabilities[x][4][0]=3;
		probabilities[x][4][1]=40;
		probabilities[x][5][0]=4;
		probabilities[x][5][1]=40;
		probabilities[x][6][0]=4;
		probabilities[x][6][1]=40;
		probabilities[x][7][0]=4;
		probabilities[x][7][1]=40;
		probabilities[x][8][0]=5;
		probabilities[x][8][1]=40;
		probabilities[x][9][0]=8;
		probabilities[x][9][1]=40;
		probabilities[x][10][0]=1;
		probabilities[x][10][1]=40;
		probabilities[x][11][0]=6;
		probabilities[x][11][1]=40;
		for(int i=0; i<10; i++){
			for(int j=0; j<10; j++){
				all_moves[x][i][j]=0;
			}
		}
	}
	if(top){
		int i=0;
		for(x=0; x<10; x++){
			for(int y=0; y<4; y++){
				opponentPieces[i]->update_coordinates(x, y);
				board[x][y]=opponentPieces[i];
				board_piece_mappings[x][y]=i;
				i++;
			}
		}
	}
	else{
		int i=0;
		for(x=0; x<10; x++){
			for(int y=6; y<10; y++){
				opponentPieces[i]->update_coordinates(x, y);
				board[x][y]=opponentPieces[i];
				board_piece_mappings[x][y]=i;
				i++;
			}
		}
	}
}

one_ply_bot::~one_ply_bot(){
	for(int x=0; x<40; x++){
		delete myPieces[x];
	}
}

void oevaluator(gamePiece *myPieces[40], gamePiece *opponentPieces[40], bool known[40], bool top, int probabilities[40][12][2], float &discovery, float &material, float &bombs, float &attack, float &unknown, bool do_bombs, bool do_unknown){
	bombs=0;
	discovery=0;
	material=0;
	attack=0;
	unknown=0;
	for(int x=0; x<40; x++){
		if (known[x])
			discovery+=1;
		
		if(do_bombs){
			if(opponentPieces[x]->getX()!=-1 && probabilities[x][11][0]!=0){
				for(int i=19; i<24; i++){
					if(myPieces[i]->getX()!=-1){
						bombs+=abs(myPieces[i]->getX()-opponentPieces[x]->getX());
						bombs+=abs(myPieces[i]->getY()-opponentPieces[x]->getY());
					}
				}
			}
		}

		if(top && myPieces[x]->getX()!=-1){
			attack+=(9-myPieces[x]->getY());
		}
		if(!top && myPieces[x]->getX()!=-1){
			attack+=myPieces[x]->getY();
		}

		if(do_unknown && !known[x]){
			int x_coord=opponentPieces[x]->getX();
			int y_coord=opponentPieces[x]->getY();
			for(int y=0; y<40; y++){
				if(myPieces[y]->getX()!=-1){
					unknown+=abs(myPieces[y]->getX()-x_coord);
					unknown+=abs(myPieces[y]->getY()-y_coord);
				}
			}
		}

		if(myPieces[x]->getX()>-1){
			if(myPieces[x]->getPieceType()==0)
				material+=100;
			else if(myPieces[x]->getPieceType()==1)
				material+=90;
			else if(myPieces[x]->getPieceType()==2)
				material+=80;
			else if(myPieces[x]->getPieceType()==3)
				material+=70;
			else if(myPieces[x]->getPieceType()==4)
				material+=60;
			else if(myPieces[x]->getPieceType()==5)
				material+=50;
			else if(myPieces[x]->getPieceType()==6)
				material+=40;
			else if(myPieces[x]->getPieceType()==7)
				material+=30;
			else if(myPieces[x]->getPieceType()==8)
				material+=100;
			else if(myPieces[x]->getPieceType()==9)
				material+=10;
			else if(myPieces[x]->getPieceType()==10)
				material+=30;
			else if(myPieces[x]->getPieceType()==11)
				material+=50;
		}
	}
	discovery/=40.0;
	material/=1980.0;
	bombs = (2000-bombs)/2000.0;
	attack/=300.0;
	unknown=(15000-unknown)/15000.0;
}

float oflag(gamePiece *myPieces[40], gamePiece *board[10][10]){
	int flag_x = myPieces[39]->getX();
	int flag_y = myPieces[39]->getY();
	float vulnerabilities=0;
	for(int x=flag_x-2; x<flag_x+2; x++){
		if(x<0 || x>9) continue;
		for(int y=flag_y-2; y<flag_y+2; y++){
			if(y<0 || y>9) continue;
			if((x==2 || x==3 || x==6 || x==7) && (y==4 || y==5)) continue;
			if(x==flag_x && y==flag_y) continue;
			if(board[x][y]==NULL) vulnerabilities+=0.9;
			else if(board[x][y]->getPlayerType()==User) vulnerabilities+=1.0;
			else if(board[x][y]->getPieceType()==General) vulnerabilities+=0.1;
			else if(board[x][y]->getPieceType()==Colonel) vulnerabilities+=0.2;
			else if(board[x][y]->getPieceType()==Major) vulnerabilities+=0.3;
			else if(board[x][y]->getPieceType()==Captain) vulnerabilities+=0.4;
			else if(board[x][y]->getPieceType()==Lieutenant) vulnerabilities+=0.5;
			else if(board[x][y]->getPieceType()==Sergeant) vulnerabilities+=0.6;
			else if(board[x][y]->getPieceType()==Miner) vulnerabilities+=0.7;
			else if(board[x][y]->getPieceType()==Scout) vulnerabilities+=0.9;
			else if(board[x][y]->getPieceType()==Spy) vulnerabilities+=0.95;
			else if(board[x][y]->getPieceType()==Bomb) vulnerabilities+=0.25;
		}
	}
	return 1.0-(vulnerabilities/22.0);
}

float oheuristic(bool known[40], gamePiece *myPieces[40], gamePiece *board[10][10], gamePiece *opponentPieces[40], int probabilities[40][12][2], int move_count, int pieces_left, bool top){
	float value=0;
	float discovery;
	float material;
	float bombs;
	float attack;
	float unknown;
	bool do_bombs=false;
	bool do_unknown=false;
	if(move_count>70 && move_count<140 && pieces_left < 25)
		do_bombs=true;
	else if(move_count>=200 && pieces_left < 15)
		do_unknown=true;
	oevaluator(myPieces, opponentPieces, known, top, probabilities, discovery, material, bombs, attack, unknown, do_bombs, do_unknown);
	value += 0.25*discovery;
	value += 0.25*material;
	value += 0.25*oflag(myPieces, board);
	value += 0.01*attack;
	value += 0.01*unknown;
	if(move_count>70 && move_count<140 && pieces_left < 25)
		value += 0.25*bombs;
	else if(move_count>=140 && move_count<200 && pieces_left < 20)
		value += 0.35*bombs;
	else if(move_count>=200 && pieces_left < 15)
		value += 0.4*bombs;
	return value;
}

void oboard1(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(1, 8);
			board[1][8]=myPieces[0];
			myPieces[1]->update_coordinates(0, 7);
			board[0][7]=myPieces[1];
			myPieces[2]->update_coordinates(1, 7);
			board[1][7]=myPieces[2];
			myPieces[3]->update_coordinates(5, 7);
			board[5][7]=myPieces[3];
			myPieces[4]->update_coordinates(3, 6);
			board[3][6]=myPieces[4];
			myPieces[5]->update_coordinates(5, 8);
			board[5][8]=myPieces[5];
			myPieces[6]->update_coordinates(8, 7);
			board[8][7]=myPieces[6];
			myPieces[7]->update_coordinates(4, 7);
			board[4][7]=myPieces[7];
			myPieces[8]->update_coordinates(6, 8);
			board[6][8]=myPieces[8];
			myPieces[9]->update_coordinates(6, 7);
			board[6][7]=myPieces[9];
			myPieces[10]->update_coordinates(7, 7);
			board[7][7]=myPieces[10];
			myPieces[11]->update_coordinates(2, 8);
			board[2][8]=myPieces[11];
			myPieces[12]->update_coordinates(7, 8);
			board[7][8]=myPieces[12];
			myPieces[13]->update_coordinates(8, 8);
			board[8][8]=myPieces[13];
			myPieces[14]->update_coordinates(9, 8);
			board[9][8]=myPieces[14];
			myPieces[15]->update_coordinates(6, 6);
			board[6][6]=myPieces[15];
			myPieces[16]->update_coordinates(7, 6);
			board[7][6]=myPieces[16];
			myPieces[17]->update_coordinates(9, 9);
			board[9][9]=myPieces[17];
			myPieces[18]->update_coordinates(9, 7);
			board[9][7]=myPieces[18];
			myPieces[19]->update_coordinates(2, 6);
			board[2][6]=myPieces[19];
			myPieces[20]->update_coordinates(3, 8);
			board[3][8]=myPieces[20];
			myPieces[21]->update_coordinates(3, 7);
			board[3][7]=myPieces[21];
			myPieces[22]->update_coordinates(4, 8);
			board[4][8]=myPieces[22];
			myPieces[23]->update_coordinates(8, 9);
			board[8][9]=myPieces[23];
			myPieces[24]->update_coordinates(0, 6);
			board[0][6]=myPieces[24];
			myPieces[25]->update_coordinates(1, 6);
			board[1][6]=myPieces[25];
			myPieces[26]->update_coordinates(2, 9);
			board[2][9]=myPieces[26];
			myPieces[27]->update_coordinates(3, 9);
			board[3][9]=myPieces[27];
			myPieces[28]->update_coordinates(4, 9);
			board[4][9]=myPieces[28];
			myPieces[29]->update_coordinates(5, 9);
			board[5][9]=myPieces[29];
			myPieces[30]->update_coordinates(6, 9);
			board[6][9]=myPieces[30];
			myPieces[31]->update_coordinates(7, 9);
			board[7][9]=myPieces[31];
			myPieces[32]->update_coordinates(2, 7);
			board[2][7]=myPieces[32];
			myPieces[33]->update_coordinates(0, 8);
			board[0][8]=myPieces[33];
			myPieces[34]->update_coordinates(1, 9);
			board[1][9]=myPieces[34];
			myPieces[35]->update_coordinates(4, 6);
			board[4][6]=myPieces[35];
			myPieces[36]->update_coordinates(5, 6);
			board[5][6]=myPieces[36];
			myPieces[37]->update_coordinates(8, 6);
			board[8][6]=myPieces[37];
			myPieces[38]->update_coordinates(9, 6);
			board[9][6]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(1, 1);
			board[1][1]=myPieces[0];
			myPieces[1]->update_coordinates(0, 2);
			board[0][2]=myPieces[1];
			myPieces[2]->update_coordinates(1, 2);
			board[1][2]=myPieces[2];
			myPieces[3]->update_coordinates(5, 2);
			board[5][2]=myPieces[3];
			myPieces[4]->update_coordinates(3, 3);
			board[3][3]=myPieces[4];
			myPieces[5]->update_coordinates(5, 1);
			board[5][1]=myPieces[5];
			myPieces[6]->update_coordinates(8, 2);
			board[8][2]=myPieces[6];
			myPieces[7]->update_coordinates(4, 2);
			board[4][2]=myPieces[7];
			myPieces[8]->update_coordinates(6, 1);
			board[6][1]=myPieces[8];
			myPieces[9]->update_coordinates(6, 2);
			board[6][2]=myPieces[9];
			myPieces[10]->update_coordinates(7, 2);
			board[7][2]=myPieces[10];
			myPieces[11]->update_coordinates(2, 1);
			board[2][1]=myPieces[11];
			myPieces[12]->update_coordinates(7, 1);
			board[7][1]=myPieces[12];
			myPieces[13]->update_coordinates(8, 1);
			board[8][1]=myPieces[13];
			myPieces[14]->update_coordinates(9, 1);
			board[9][1]=myPieces[14];
			myPieces[15]->update_coordinates(6, 3);
			board[6][3]=myPieces[15];
			myPieces[16]->update_coordinates(7, 3);
			board[7][3]=myPieces[16];
			myPieces[17]->update_coordinates(9, 0);
			board[9][0]=myPieces[17];
			myPieces[18]->update_coordinates(9, 2);
			board[9][2]=myPieces[18];
			myPieces[19]->update_coordinates(2, 3);
			board[2][3]=myPieces[19];
			myPieces[20]->update_coordinates(3, 1);
			board[3][1]=myPieces[20];
			myPieces[21]->update_coordinates(3, 2);
			board[3][2]=myPieces[21];
			myPieces[22]->update_coordinates(4, 1);
			board[4][1]=myPieces[22];
			myPieces[23]->update_coordinates(8, 0);
			board[8][0]=myPieces[23];
			myPieces[24]->update_coordinates(0, 3);
			board[0][3]=myPieces[24];
			myPieces[25]->update_coordinates(1, 3);
			board[1][3]=myPieces[25];
			myPieces[26]->update_coordinates(2, 0);
			board[2][0]=myPieces[26];
			myPieces[27]->update_coordinates(3, 0);
			board[3][0]=myPieces[27];
			myPieces[28]->update_coordinates(4, 0);
			board[4][0]=myPieces[28];
			myPieces[29]->update_coordinates(5, 0);
			board[5][0]=myPieces[29];
			myPieces[30]->update_coordinates(6, 0);
			board[6][0]=myPieces[30];
			myPieces[31]->update_coordinates(7, 0);
			board[7][0]=myPieces[31];
			myPieces[32]->update_coordinates(2, 2);
			board[2][2]=myPieces[32];
			myPieces[33]->update_coordinates(0, 1);
			board[0][1]=myPieces[33];
			myPieces[34]->update_coordinates(1, 0);
			board[1][0]=myPieces[34];
			myPieces[35]->update_coordinates(4, 3);
			board[4][3]=myPieces[35];
			myPieces[36]->update_coordinates(5, 3);
			board[5][3]=myPieces[36];
			myPieces[37]->update_coordinates(8, 3);
			board[8][3]=myPieces[37];
			myPieces[38]->update_coordinates(9, 3);
			board[9][3]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}

void oboard2(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(2, 6);
			board[2][6]=myPieces[0];
			myPieces[1]->update_coordinates(1, 6);
			board[1][6]=myPieces[1];
			myPieces[2]->update_coordinates(0, 7);
			board[0][7]=myPieces[2];
			myPieces[3]->update_coordinates(4, 8);
			board[4][8]=myPieces[3];
			myPieces[4]->update_coordinates(1, 8);
			board[1][8]=myPieces[4];
			myPieces[5]->update_coordinates(5, 8);
			board[5][8]=myPieces[5];
			myPieces[6]->update_coordinates(7, 8);
			board[7][8]=myPieces[6];
			myPieces[7]->update_coordinates(3, 7);
			board[3][7]=myPieces[7];
			myPieces[8]->update_coordinates(5, 9);
			board[5][9]=myPieces[8];
			myPieces[9]->update_coordinates(8, 9);
			board[8][9]=myPieces[9];
			myPieces[10]->update_coordinates(9, 7);
			board[9][7]=myPieces[10];
			myPieces[11]->update_coordinates(5, 6);
			board[5][6]=myPieces[11];
			myPieces[12]->update_coordinates(7, 6);
			board[7][6]=myPieces[12];
			myPieces[13]->update_coordinates(8, 7);
			board[8][7]=myPieces[13];
			myPieces[14]->update_coordinates(8, 6);
			board[8][6]=myPieces[14];
			myPieces[15]->update_coordinates(4, 7);
			board[4][7]=myPieces[15];
			myPieces[16]->update_coordinates(4, 6);
			board[4][6]=myPieces[16];
			myPieces[17]->update_coordinates(6, 6);
			board[6][6]=myPieces[17];
			myPieces[18]->update_coordinates(8, 8);
			board[8][8]=myPieces[18];
			myPieces[19]->update_coordinates(2, 9);
			board[2][9]=myPieces[19];
			myPieces[20]->update_coordinates(2, 8);
			board[2][8]=myPieces[20];
			myPieces[21]->update_coordinates(3, 9);
			board[3][9]=myPieces[21];
			myPieces[22]->update_coordinates(3, 8);
			board[3][8]=myPieces[22];
			myPieces[23]->update_coordinates(4, 9);
			board[4][9]=myPieces[23];
			myPieces[24]->update_coordinates(3, 6);
			board[3][6]=myPieces[24];
			myPieces[25]->update_coordinates(5, 7);
			board[5][7]=myPieces[25];
			myPieces[26]->update_coordinates(6, 9);
			board[6][9]=myPieces[26];
			myPieces[27]->update_coordinates(6, 8);
			board[6][8]=myPieces[27];
			myPieces[28]->update_coordinates(6, 7);
			board[6][7]=myPieces[28];
			myPieces[29]->update_coordinates(7, 9);
			board[7][9]=myPieces[29];
			myPieces[30]->update_coordinates(9, 9);
			board[9][9]=myPieces[30];
			myPieces[31]->update_coordinates(9, 8);
			board[9][8]=myPieces[31];
			myPieces[32]->update_coordinates(1, 7);
			board[1][7]=myPieces[32];
			myPieces[33]->update_coordinates(0, 6);
			board[0][6]=myPieces[33];
			myPieces[34]->update_coordinates(1, 9);
			board[1][9]=myPieces[34];
			myPieces[35]->update_coordinates(2, 7);
			board[2][7]=myPieces[35];
			myPieces[36]->update_coordinates(7, 7);
			board[7][7]=myPieces[36];
			myPieces[37]->update_coordinates(9, 6);
			board[9][6]=myPieces[37];
			myPieces[38]->update_coordinates(0, 8);
			board[0][8]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(2, 3);
			board[2][3]=myPieces[0];
			myPieces[1]->update_coordinates(1, 3);
			board[1][3]=myPieces[1];
			myPieces[2]->update_coordinates(0, 2);
			board[0][2]=myPieces[2];
			myPieces[3]->update_coordinates(4, 1);
			board[4][1]=myPieces[3];
			myPieces[4]->update_coordinates(1, 1);
			board[1][1]=myPieces[4];
			myPieces[5]->update_coordinates(5, 1);
			board[5][1]=myPieces[5];
			myPieces[6]->update_coordinates(7, 1);
			board[7][1]=myPieces[6];
			myPieces[7]->update_coordinates(3, 2);
			board[3][2]=myPieces[7];
			myPieces[8]->update_coordinates(5, 0);
			board[5][0]=myPieces[8];
			myPieces[9]->update_coordinates(8, 0);
			board[8][0]=myPieces[9];
			myPieces[10]->update_coordinates(9, 2);
			board[9][2]=myPieces[10];
			myPieces[11]->update_coordinates(5, 3);
			board[5][3]=myPieces[11];
			myPieces[12]->update_coordinates(7, 3);
			board[7][3]=myPieces[12];
			myPieces[13]->update_coordinates(8, 2);
			board[8][2]=myPieces[13];
			myPieces[14]->update_coordinates(8, 3);
			board[8][3]=myPieces[14];
			myPieces[15]->update_coordinates(4, 2);
			board[4][2]=myPieces[15];
			myPieces[16]->update_coordinates(4, 3);
			board[4][3]=myPieces[16];
			myPieces[17]->update_coordinates(6, 3);
			board[6][3]=myPieces[17];
			myPieces[18]->update_coordinates(8, 1);
			board[8][1]=myPieces[18];
			myPieces[19]->update_coordinates(2, 0);
			board[2][0]=myPieces[19];
			myPieces[20]->update_coordinates(2, 1);
			board[2][1]=myPieces[20];
			myPieces[21]->update_coordinates(3, 0);
			board[3][0]=myPieces[21];
			myPieces[22]->update_coordinates(3, 1);
			board[3][1]=myPieces[22];
			myPieces[23]->update_coordinates(4, 0);
			board[4][0]=myPieces[23];
			myPieces[24]->update_coordinates(3, 3);
			board[3][3]=myPieces[24];
			myPieces[25]->update_coordinates(5, 2);
			board[5][2]=myPieces[25];
			myPieces[26]->update_coordinates(6, 0);
			board[6][0]=myPieces[26];
			myPieces[27]->update_coordinates(6, 1);
			board[6][1]=myPieces[27];
			myPieces[28]->update_coordinates(6, 2);
			board[6][2]=myPieces[28];
			myPieces[29]->update_coordinates(7, 0);
			board[7][0]=myPieces[29];
			myPieces[30]->update_coordinates(9, 0);
			board[9][0]=myPieces[30];
			myPieces[31]->update_coordinates(9, 1);
			board[9][1]=myPieces[31];
			myPieces[32]->update_coordinates(1, 2);
			board[1][2]=myPieces[32];
			myPieces[33]->update_coordinates(0, 3);
			board[0][3]=myPieces[33];
			myPieces[34]->update_coordinates(1, 0);
			board[1][0]=myPieces[34];
			myPieces[35]->update_coordinates(2, 2);
			board[2][2]=myPieces[35];
			myPieces[36]->update_coordinates(7, 2);
			board[7][2]=myPieces[36];
			myPieces[37]->update_coordinates(9, 3);
			board[9][3]=myPieces[37];
			myPieces[38]->update_coordinates(0, 1);
			board[0][1]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}

void oboard3(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(2, 6);
			board[2][6]=myPieces[0];
			myPieces[1]->update_coordinates(7, 7);
			board[7][7]=myPieces[1];
			myPieces[2]->update_coordinates(5, 7);
			board[5][7]=myPieces[2];
			myPieces[3]->update_coordinates(7, 6);
			board[7][6]=myPieces[3];
			myPieces[4]->update_coordinates(0, 7);
			board[0][7]=myPieces[4];
			myPieces[5]->update_coordinates(3, 7);
			board[3][7]=myPieces[5];
			myPieces[6]->update_coordinates(6, 7);
			board[6][7]=myPieces[6];
			myPieces[7]->update_coordinates(0, 8);
			board[0][8]=myPieces[7];
			myPieces[8]->update_coordinates(7, 9);
			board[7][9]=myPieces[8];
			myPieces[9]->update_coordinates(7, 8);
			board[7][8]=myPieces[9];
			myPieces[10]->update_coordinates(8, 9);
			board[8][9]=myPieces[10];
			myPieces[11]->update_coordinates(2, 8);
			board[2][8]=myPieces[11];
			myPieces[12]->update_coordinates(6, 9);
			board[6][9]=myPieces[12];
			myPieces[13]->update_coordinates(8, 6);
			board[8][6]=myPieces[13];
			myPieces[14]->update_coordinates(9, 8);
			board[9][8]=myPieces[14];
			myPieces[15]->update_coordinates(1, 9);
			board[1][9]=myPieces[15];
			myPieces[16]->update_coordinates(1, 6);
			board[1][6]=myPieces[16];
			myPieces[17]->update_coordinates(4, 7);
			board[4][7]=myPieces[17];
			myPieces[18]->update_coordinates(5, 8);
			board[5][8]=myPieces[18];
			myPieces[19]->update_coordinates(4, 8);
			board[4][8]=myPieces[19];
			myPieces[20]->update_coordinates(5, 9);
			board[5][9]=myPieces[20];
			myPieces[21]->update_coordinates(8, 8);
			board[8][8]=myPieces[21];
			myPieces[22]->update_coordinates(8, 7);
			board[8][7]=myPieces[22];
			myPieces[23]->update_coordinates(9, 9);
			board[9][9]=myPieces[23];
			myPieces[24]->update_coordinates(0, 9);
			board[0][9]=myPieces[24];
			myPieces[25]->update_coordinates(0, 6);
			board[0][6]=myPieces[25];
			myPieces[26]->update_coordinates(3, 6);
			board[3][6]=myPieces[26];
			myPieces[27]->update_coordinates(4, 6);
			board[4][6]=myPieces[27];
			myPieces[28]->update_coordinates(6, 8);
			board[6][8]=myPieces[28];
			myPieces[29]->update_coordinates(6, 6);
			board[6][6]=myPieces[29];
			myPieces[30]->update_coordinates(9, 7);
			board[9][7]=myPieces[30];
			myPieces[31]->update_coordinates(9, 6);
			board[9][6]=myPieces[31];
			myPieces[32]->update_coordinates(2, 7);
			board[2][7]=myPieces[32];
			myPieces[33]->update_coordinates(1, 8);
			board[1][8]=myPieces[33];
			myPieces[34]->update_coordinates(1, 7);
			board[1][7]=myPieces[34];
			myPieces[35]->update_coordinates(2, 9);
			board[2][9]=myPieces[35];
			myPieces[36]->update_coordinates(3, 8);
			board[3][8]=myPieces[36];
			myPieces[37]->update_coordinates(4, 9);
			board[4][9]=myPieces[37];
			myPieces[38]->update_coordinates(5, 6);
			board[5][6]=myPieces[38];
			myPieces[39]->update_coordinates(3, 9);
			board[3][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(2, 3);
			board[2][3]=myPieces[0];
			myPieces[1]->update_coordinates(7, 2);
			board[7][2]=myPieces[1];
			myPieces[2]->update_coordinates(5, 2);
			board[5][2]=myPieces[2];
			myPieces[3]->update_coordinates(7, 3);
			board[7][3]=myPieces[3];
			myPieces[4]->update_coordinates(0, 2);
			board[0][2]=myPieces[4];
			myPieces[5]->update_coordinates(3, 2);
			board[3][2]=myPieces[5];
			myPieces[6]->update_coordinates(6, 2);
			board[6][2]=myPieces[6];
			myPieces[7]->update_coordinates(0, 1);
			board[0][1]=myPieces[7];
			myPieces[8]->update_coordinates(7, 0);
			board[7][0]=myPieces[8];
			myPieces[9]->update_coordinates(7, 1);
			board[7][1]=myPieces[9];
			myPieces[10]->update_coordinates(8, 0);
			board[8][0]=myPieces[10];
			myPieces[11]->update_coordinates(2, 1);
			board[2][1]=myPieces[11];
			myPieces[12]->update_coordinates(6, 0);
			board[6][0]=myPieces[12];
			myPieces[13]->update_coordinates(8, 3);
			board[8][3]=myPieces[13];
			myPieces[14]->update_coordinates(9, 1);
			board[9][1]=myPieces[14];
			myPieces[15]->update_coordinates(1, 0);
			board[1][0]=myPieces[15];
			myPieces[16]->update_coordinates(1, 3);
			board[1][3]=myPieces[16];
			myPieces[17]->update_coordinates(4, 2);
			board[4][2]=myPieces[17];
			myPieces[18]->update_coordinates(5, 1);
			board[5][1]=myPieces[18];
			myPieces[19]->update_coordinates(4, 1);
			board[4][1]=myPieces[19];
			myPieces[20]->update_coordinates(5, 0);
			board[5][0]=myPieces[20];
			myPieces[21]->update_coordinates(8, 1);
			board[8][1]=myPieces[21];
			myPieces[22]->update_coordinates(8, 2);
			board[8][2]=myPieces[22];
			myPieces[23]->update_coordinates(9, 0);
			board[9][0]=myPieces[23];
			myPieces[24]->update_coordinates(0, 0);
			board[0][0]=myPieces[24];
			myPieces[25]->update_coordinates(0, 3);
			board[0][3]=myPieces[25];
			myPieces[26]->update_coordinates(3, 3);
			board[3][3]=myPieces[26];
			myPieces[27]->update_coordinates(4, 3);
			board[4][3]=myPieces[27];
			myPieces[28]->update_coordinates(6, 1);
			board[6][1]=myPieces[28];
			myPieces[29]->update_coordinates(6, 3);
			board[6][3]=myPieces[29];
			myPieces[30]->update_coordinates(9, 2);
			board[9][2]=myPieces[30];
			myPieces[31]->update_coordinates(9, 3);
			board[9][3]=myPieces[31];
			myPieces[32]->update_coordinates(2, 2);
			board[2][2]=myPieces[32];
			myPieces[33]->update_coordinates(1, 1);
			board[1][1]=myPieces[33];
			myPieces[34]->update_coordinates(1, 2);
			board[1][2]=myPieces[34];
			myPieces[35]->update_coordinates(2, 0);
			board[2][0]=myPieces[35];
			myPieces[36]->update_coordinates(3, 1);
			board[3][1]=myPieces[36];
			myPieces[37]->update_coordinates(4, 0);
			board[4][0]=myPieces[37];
			myPieces[38]->update_coordinates(5, 3);
			board[5][3]=myPieces[38];
			myPieces[39]->update_coordinates(3, 0);
			board[3][0]=myPieces[39];
		}
	}
}

void oboard4(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(8, 7);
			board[8][7]=myPieces[0];
			myPieces[1]->update_coordinates(2, 6);
			board[2][6]=myPieces[1];
			myPieces[2]->update_coordinates(4, 7);
			board[4][7]=myPieces[2];
			myPieces[3]->update_coordinates(8, 6);
			board[8][6]=myPieces[3];
			myPieces[4]->update_coordinates(0, 8);
			board[0][8]=myPieces[4];
			myPieces[5]->update_coordinates(1, 6);
			board[1][6]=myPieces[5];
			myPieces[6]->update_coordinates(9, 9);
			board[9][9]=myPieces[6];
			myPieces[7]->update_coordinates(3, 6);
			board[3][6]=myPieces[7];
			myPieces[8]->update_coordinates(4, 8);
			board[4][8]=myPieces[8];
			myPieces[9]->update_coordinates(5, 7);
			board[5][7]=myPieces[9];
			myPieces[10]->update_coordinates(6, 6);
			board[6][6]=myPieces[10];
			myPieces[11]->update_coordinates(2, 8);
			board[2][8]=myPieces[11];
			myPieces[12]->update_coordinates(5, 9);
			board[5][9]=myPieces[12];
			myPieces[13]->update_coordinates(6, 7);
			board[6][7]=myPieces[13];
			myPieces[14]->update_coordinates(8, 8);
			board[8][8]=myPieces[14];
			myPieces[15]->update_coordinates(3, 9);
			board[3][9]=myPieces[15];
			myPieces[16]->update_coordinates(5, 6);
			board[5][6]=myPieces[16];
			myPieces[17]->update_coordinates(9, 8);
			board[9][8]=myPieces[17];
			myPieces[18]->update_coordinates(9, 6);
			board[9][6]=myPieces[18];
			myPieces[19]->update_coordinates(3, 7);
			board[3][7]=myPieces[19];
			myPieces[20]->update_coordinates(5, 8);
			board[5][8]=myPieces[20];
			myPieces[21]->update_coordinates(6, 9);
			board[6][9]=myPieces[21];
			myPieces[22]->update_coordinates(7, 7);
			board[7][7]=myPieces[22];
			myPieces[23]->update_coordinates(8, 9);
			board[8][9]=myPieces[23];
			myPieces[24]->update_coordinates(0, 6);
			board[0][6]=myPieces[24];
			myPieces[25]->update_coordinates(1, 7);
			board[1][7]=myPieces[25];
			myPieces[26]->update_coordinates(2, 7);
			board[2][7]=myPieces[26];
			myPieces[27]->update_coordinates(4, 9);
			board[4][9]=myPieces[27];
			myPieces[28]->update_coordinates(4, 6);
			board[4][6]=myPieces[28];
			myPieces[29]->update_coordinates(7, 9);
			board[7][9]=myPieces[29];
			myPieces[30]->update_coordinates(7, 6);
			board[7][6]=myPieces[30];
			myPieces[31]->update_coordinates(9, 7);
			board[9][7]=myPieces[31];
			myPieces[32]->update_coordinates(7, 8);
			board[7][8]=myPieces[32];
			myPieces[33]->update_coordinates(0, 9);
			board[0][9]=myPieces[33];
			myPieces[34]->update_coordinates(0, 7);
			board[0][7]=myPieces[34];
			myPieces[35]->update_coordinates(1, 8);
			board[1][8]=myPieces[35];
			myPieces[36]->update_coordinates(2, 9);
			board[2][9]=myPieces[36];
			myPieces[37]->update_coordinates(3, 8);
			board[3][8]=myPieces[37];
			myPieces[38]->update_coordinates(6, 8);
			board[6][8]=myPieces[38];
			myPieces[39]->update_coordinates(1, 9);
			board[1][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(8, 2);
			board[8][2]=myPieces[0];
			myPieces[1]->update_coordinates(2, 3);
			board[2][3]=myPieces[1];
			myPieces[2]->update_coordinates(4, 2);
			board[4][2]=myPieces[2];
			myPieces[3]->update_coordinates(8, 3);
			board[8][3]=myPieces[3];
			myPieces[4]->update_coordinates(0, 1);
			board[0][1]=myPieces[4];
			myPieces[5]->update_coordinates(1, 3);
			board[1][3]=myPieces[5];
			myPieces[6]->update_coordinates(9, 0);
			board[9][0]=myPieces[6];
			myPieces[7]->update_coordinates(3, 3);
			board[3][3]=myPieces[7];
			myPieces[8]->update_coordinates(4, 1);
			board[4][1]=myPieces[8];
			myPieces[9]->update_coordinates(5, 2);
			board[5][2]=myPieces[9];
			myPieces[10]->update_coordinates(6, 3);
			board[6][3]=myPieces[10];
			myPieces[11]->update_coordinates(2, 1);
			board[2][1]=myPieces[11];
			myPieces[12]->update_coordinates(5, 0);
			board[5][0]=myPieces[12];
			myPieces[13]->update_coordinates(6, 2);
			board[6][2]=myPieces[13];
			myPieces[14]->update_coordinates(8, 1);
			board[8][1]=myPieces[14];
			myPieces[15]->update_coordinates(3, 0);
			board[3][0]=myPieces[15];
			myPieces[16]->update_coordinates(5, 3);
			board[5][3]=myPieces[16];
			myPieces[17]->update_coordinates(9, 1);
			board[9][1]=myPieces[17];
			myPieces[18]->update_coordinates(9, 3);
			board[9][3]=myPieces[18];
			myPieces[19]->update_coordinates(3, 2);
			board[3][2]=myPieces[19];
			myPieces[20]->update_coordinates(5, 1);
			board[5][1]=myPieces[20];
			myPieces[21]->update_coordinates(6, 0);
			board[6][0]=myPieces[21];
			myPieces[22]->update_coordinates(7, 2);
			board[7][2]=myPieces[22];
			myPieces[23]->update_coordinates(8, 0);
			board[8][0]=myPieces[23];
			myPieces[24]->update_coordinates(0, 3);
			board[0][3]=myPieces[24];
			myPieces[25]->update_coordinates(1, 2);
			board[1][2]=myPieces[25];
			myPieces[26]->update_coordinates(2, 2);
			board[2][2]=myPieces[26];
			myPieces[27]->update_coordinates(4, 0);
			board[4][0]=myPieces[27];
			myPieces[28]->update_coordinates(4, 3);
			board[4][3]=myPieces[28];
			myPieces[29]->update_coordinates(7, 0);
			board[7][0]=myPieces[29];
			myPieces[30]->update_coordinates(7, 3);
			board[7][3]=myPieces[30];
			myPieces[31]->update_coordinates(9, 2);
			board[9][2]=myPieces[31];
			myPieces[32]->update_coordinates(7, 1);
			board[7][1]=myPieces[32];
			myPieces[33]->update_coordinates(0, 0);
			board[0][0]=myPieces[33];
			myPieces[34]->update_coordinates(0, 2);
			board[0][2]=myPieces[34];
			myPieces[35]->update_coordinates(1, 1);
			board[1][1]=myPieces[35];
			myPieces[36]->update_coordinates(2, 0);
			board[2][0]=myPieces[36];
			myPieces[37]->update_coordinates(3, 1);
			board[3][1]=myPieces[37];
			myPieces[38]->update_coordinates(6, 1);
			board[6][1]=myPieces[38];
			myPieces[39]->update_coordinates(1, 0);
			board[1][0]=myPieces[39];
		}
	}
}

void oboard5(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(5, 7);
			board[5][7]=myPieces[0];
			myPieces[1]->update_coordinates(6, 9);
			board[6][9]=myPieces[1];
			myPieces[2]->update_coordinates(0, 8);
			board[0][8]=myPieces[2];
			myPieces[3]->update_coordinates(4, 8);
			board[4][8]=myPieces[3];
			myPieces[4]->update_coordinates(1, 7);
			board[1][7]=myPieces[4];
			myPieces[5]->update_coordinates(2, 6);
			board[2][6]=myPieces[5];
			myPieces[6]->update_coordinates(7, 6);
			board[7][6]=myPieces[6];
			myPieces[7]->update_coordinates(2, 8);
			board[2][8]=myPieces[7];
			myPieces[8]->update_coordinates(4, 6);
			board[4][6]=myPieces[8];
			myPieces[9]->update_coordinates(7, 7);
			board[7][7]=myPieces[9];
			myPieces[10]->update_coordinates(9, 9);
			board[9][9]=myPieces[10];
			myPieces[11]->update_coordinates(0, 9);
			board[0][9]=myPieces[11];
			myPieces[12]->update_coordinates(0, 6);
			board[0][6]=myPieces[12];
			myPieces[13]->update_coordinates(1, 8);
			board[1][8]=myPieces[13];
			myPieces[14]->update_coordinates(5, 9);
			board[5][9]=myPieces[14];
			myPieces[15]->update_coordinates(3, 6);
			board[3][6]=myPieces[15];
			myPieces[16]->update_coordinates(5, 6);
			board[5][6]=myPieces[16];
			myPieces[17]->update_coordinates(6, 8);
			board[6][8]=myPieces[17];
			myPieces[18]->update_coordinates(8, 7);
			board[8][7]=myPieces[18];
			myPieces[19]->update_coordinates(0, 7);
			board[0][7]=myPieces[19];
			myPieces[20]->update_coordinates(1, 9);
			board[1][9]=myPieces[20];
			myPieces[21]->update_coordinates(3, 7);
			board[3][7]=myPieces[21];
			myPieces[22]->update_coordinates(4, 7);
			board[4][7]=myPieces[22];
			myPieces[23]->update_coordinates(7, 8);
			board[7][8]=myPieces[23];
			myPieces[24]->update_coordinates(1, 6);
			board[1][6]=myPieces[24];
			myPieces[25]->update_coordinates(6, 7);
			board[6][7]=myPieces[25];
			myPieces[26]->update_coordinates(6, 6);
			board[6][6]=myPieces[26];
			myPieces[27]->update_coordinates(7, 9);
			board[7][9]=myPieces[27];
			myPieces[28]->update_coordinates(8, 8);
			board[8][8]=myPieces[28];
			myPieces[29]->update_coordinates(8, 6);
			board[8][6]=myPieces[29];
			myPieces[30]->update_coordinates(9, 7);
			board[9][7]=myPieces[30];
			myPieces[31]->update_coordinates(9, 6);
			board[9][6]=myPieces[31];
			myPieces[32]->update_coordinates(5, 8);
			board[5][8]=myPieces[32];
			myPieces[33]->update_coordinates(2, 9);
			board[2][9]=myPieces[33];
			myPieces[34]->update_coordinates(2, 7);
			board[2][7]=myPieces[34];
			myPieces[35]->update_coordinates(3, 8);
			board[3][8]=myPieces[35];
			myPieces[36]->update_coordinates(4, 9);
			board[4][9]=myPieces[36];
			myPieces[37]->update_coordinates(8, 9);
			board[8][9]=myPieces[37];
			myPieces[38]->update_coordinates(9, 8);
			board[9][8]=myPieces[38];
			myPieces[39]->update_coordinates(3, 9);
			board[3][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(5, 2);
			board[5][2]=myPieces[0];
			myPieces[1]->update_coordinates(6, 0);
			board[6][0]=myPieces[1];
			myPieces[2]->update_coordinates(0, 1);
			board[0][1]=myPieces[2];
			myPieces[3]->update_coordinates(4, 1);
			board[4][1]=myPieces[3];
			myPieces[4]->update_coordinates(1, 2);
			board[1][2]=myPieces[4];
			myPieces[5]->update_coordinates(2, 3);
			board[2][3]=myPieces[5];
			myPieces[6]->update_coordinates(7, 3);
			board[7][3]=myPieces[6];
			myPieces[7]->update_coordinates(2, 1);
			board[2][1]=myPieces[7];
			myPieces[8]->update_coordinates(4, 3);
			board[4][3]=myPieces[8];
			myPieces[9]->update_coordinates(7, 2);
			board[7][2]=myPieces[9];
			myPieces[10]->update_coordinates(9, 0);
			board[9][0]=myPieces[10];
			myPieces[11]->update_coordinates(0, 0);
			board[0][0]=myPieces[11];
			myPieces[12]->update_coordinates(0, 3);
			board[0][3]=myPieces[12];
			myPieces[13]->update_coordinates(1, 1);
			board[1][1]=myPieces[13];
			myPieces[14]->update_coordinates(5, 0);
			board[5][0]=myPieces[14];
			myPieces[15]->update_coordinates(3, 3);
			board[3][3]=myPieces[15];
			myPieces[16]->update_coordinates(5, 3);
			board[5][3]=myPieces[16];
			myPieces[17]->update_coordinates(6, 1);
			board[6][1]=myPieces[17];
			myPieces[18]->update_coordinates(8, 2);
			board[8][2]=myPieces[18];
			myPieces[19]->update_coordinates(0, 2);
			board[0][2]=myPieces[19];
			myPieces[20]->update_coordinates(1, 0);
			board[1][0]=myPieces[20];
			myPieces[21]->update_coordinates(3, 2);
			board[3][2]=myPieces[21];
			myPieces[22]->update_coordinates(4, 2);
			board[4][2]=myPieces[22];
			myPieces[23]->update_coordinates(7, 1);
			board[7][1]=myPieces[23];
			myPieces[24]->update_coordinates(1, 3);
			board[1][3]=myPieces[24];
			myPieces[25]->update_coordinates(6, 2);
			board[6][2]=myPieces[25];
			myPieces[26]->update_coordinates(6, 3);
			board[6][3]=myPieces[26];
			myPieces[27]->update_coordinates(7, 0);
			board[7][0]=myPieces[27];
			myPieces[28]->update_coordinates(8, 1);
			board[8][1]=myPieces[28];
			myPieces[29]->update_coordinates(8, 3);
			board[8][3]=myPieces[29];
			myPieces[30]->update_coordinates(9, 2);
			board[9][2]=myPieces[30];
			myPieces[31]->update_coordinates(9, 3);
			board[9][3]=myPieces[31];
			myPieces[32]->update_coordinates(5, 1);
			board[5][1]=myPieces[32];
			myPieces[33]->update_coordinates(2, 0);
			board[2][0]=myPieces[33];
			myPieces[34]->update_coordinates(2, 2);
			board[2][2]=myPieces[34];
			myPieces[35]->update_coordinates(3, 1);
			board[3][1]=myPieces[35];
			myPieces[36]->update_coordinates(4, 0);
			board[4][0]=myPieces[36];
			myPieces[37]->update_coordinates(8, 0);
			board[8][0]=myPieces[37];
			myPieces[38]->update_coordinates(9, 1);
			board[9][1]=myPieces[38];
			myPieces[39]->update_coordinates(3, 0);
			board[3][0]=myPieces[39];
		}
	}
}

void oboard6(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(1, 8);
			board[1][8]=myPieces[0];
			myPieces[1]->update_coordinates(0, 7);
			board[0][7]=myPieces[1];
			myPieces[2]->update_coordinates(1, 7);
			board[1][7]=myPieces[2];
			myPieces[3]->update_coordinates(5, 7);
			board[5][7]=myPieces[3];
			myPieces[4]->update_coordinates(3, 6);
			board[3][6]=myPieces[4];
			myPieces[5]->update_coordinates(5, 8);
			board[5][8]=myPieces[5];
			myPieces[6]->update_coordinates(8, 7);
			board[8][7]=myPieces[6];
			myPieces[7]->update_coordinates(4, 7);
			board[4][7]=myPieces[7];
			myPieces[8]->update_coordinates(6, 8);
			board[6][8]=myPieces[8];
			myPieces[9]->update_coordinates(6, 7);
			board[6][7]=myPieces[9];
			myPieces[10]->update_coordinates(7, 7);
			board[7][7]=myPieces[10];
			myPieces[11]->update_coordinates(2, 8);
			board[2][8]=myPieces[11];
			myPieces[12]->update_coordinates(7, 8);
			board[7][8]=myPieces[12];
			myPieces[13]->update_coordinates(8, 8);
			board[8][8]=myPieces[13];
			myPieces[14]->update_coordinates(9, 8);
			board[9][8]=myPieces[14];
			myPieces[15]->update_coordinates(6, 6);
			board[6][6]=myPieces[15];
			myPieces[16]->update_coordinates(7, 6);
			board[7][6]=myPieces[16];
			myPieces[17]->update_coordinates(9, 9);
			board[9][9]=myPieces[17];
			myPieces[18]->update_coordinates(9, 7);
			board[9][7]=myPieces[18];
			myPieces[19]->update_coordinates(2, 6);
			board[2][6]=myPieces[19];
			myPieces[20]->update_coordinates(3, 8);
			board[3][8]=myPieces[20];
			myPieces[21]->update_coordinates(3, 7);
			board[3][7]=myPieces[21];
			myPieces[22]->update_coordinates(4, 8);
			board[4][8]=myPieces[22];
			myPieces[23]->update_coordinates(8, 9);
			board[8][9]=myPieces[23];
			myPieces[24]->update_coordinates(8, 6);
			board[8][6]=myPieces[24];
			myPieces[25]->update_coordinates(9, 6);
			board[9][6]=myPieces[25];
			myPieces[26]->update_coordinates(2, 9);
			board[2][9]=myPieces[26];
			myPieces[27]->update_coordinates(3, 9);
			board[3][9]=myPieces[27];
			myPieces[28]->update_coordinates(4, 9);
			board[4][9]=myPieces[28];
			myPieces[29]->update_coordinates(5, 9);
			board[5][9]=myPieces[29];
			myPieces[30]->update_coordinates(6, 9);
			board[6][9]=myPieces[30];
			myPieces[31]->update_coordinates(7, 9);
			board[7][9]=myPieces[31];
			myPieces[32]->update_coordinates(2, 7);
			board[2][7]=myPieces[32];
			myPieces[33]->update_coordinates(0, 8);
			board[0][8]=myPieces[33];
			myPieces[34]->update_coordinates(1, 9);
			board[1][9]=myPieces[34];
			myPieces[35]->update_coordinates(4, 6);
			board[4][6]=myPieces[35];
			myPieces[36]->update_coordinates(5, 6);
			board[5][6]=myPieces[36];
			myPieces[37]->update_coordinates(0, 6);
			board[0][6]=myPieces[37];
			myPieces[38]->update_coordinates(1, 6);
			board[1][6]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(1, 1);
			board[1][1]=myPieces[0];
			myPieces[1]->update_coordinates(0, 2);
			board[0][2]=myPieces[1];
			myPieces[2]->update_coordinates(1, 2);
			board[1][2]=myPieces[2];
			myPieces[3]->update_coordinates(5, 2);
			board[5][2]=myPieces[3];
			myPieces[4]->update_coordinates(3, 3);
			board[3][3]=myPieces[4];
			myPieces[5]->update_coordinates(5, 1);
			board[5][1]=myPieces[5];
			myPieces[6]->update_coordinates(8, 2);
			board[8][2]=myPieces[6];
			myPieces[7]->update_coordinates(4, 2);
			board[4][2]=myPieces[7];
			myPieces[8]->update_coordinates(6, 1);
			board[6][1]=myPieces[8];
			myPieces[9]->update_coordinates(6, 2);
			board[6][2]=myPieces[9];
			myPieces[10]->update_coordinates(7, 2);
			board[7][2]=myPieces[10];
			myPieces[11]->update_coordinates(2, 1);
			board[2][1]=myPieces[11];
			myPieces[12]->update_coordinates(7, 1);
			board[7][1]=myPieces[12];
			myPieces[13]->update_coordinates(8, 1);
			board[8][1]=myPieces[13];
			myPieces[14]->update_coordinates(9, 1);
			board[9][1]=myPieces[14];
			myPieces[15]->update_coordinates(6, 3);
			board[6][3]=myPieces[15];
			myPieces[16]->update_coordinates(7, 3);
			board[7][3]=myPieces[16];
			myPieces[17]->update_coordinates(9, 0);
			board[9][0]=myPieces[17];
			myPieces[18]->update_coordinates(9, 2);
			board[9][2]=myPieces[18];
			myPieces[19]->update_coordinates(2, 3);
			board[2][3]=myPieces[19];
			myPieces[20]->update_coordinates(3, 1);
			board[3][1]=myPieces[20];
			myPieces[21]->update_coordinates(3, 2);
			board[3][2]=myPieces[21];
			myPieces[22]->update_coordinates(4, 1);
			board[4][1]=myPieces[22];
			myPieces[23]->update_coordinates(8, 0);
			board[8][0]=myPieces[23];
			myPieces[24]->update_coordinates(8, 3);
			board[8][3]=myPieces[24];
			myPieces[25]->update_coordinates(9, 3);
			board[9][3]=myPieces[25];
			myPieces[26]->update_coordinates(2, 0);
			board[2][0]=myPieces[26];
			myPieces[27]->update_coordinates(3, 0);
			board[3][0]=myPieces[27];
			myPieces[28]->update_coordinates(4, 0);
			board[4][0]=myPieces[28];
			myPieces[29]->update_coordinates(5, 0);
			board[5][0]=myPieces[29];
			myPieces[30]->update_coordinates(6, 0);
			board[6][0]=myPieces[30];
			myPieces[31]->update_coordinates(7, 0);
			board[7][0]=myPieces[31];
			myPieces[32]->update_coordinates(2, 2);
			board[2][2]=myPieces[32];
			myPieces[33]->update_coordinates(0, 1);
			board[0][1]=myPieces[33];
			myPieces[34]->update_coordinates(1, 0);
			board[1][0]=myPieces[34];
			myPieces[35]->update_coordinates(4, 3);
			board[4][3]=myPieces[35];
			myPieces[36]->update_coordinates(5, 3);
			board[5][3]=myPieces[36];
			myPieces[37]->update_coordinates(0, 3);
			board[0][3]=myPieces[37];
			myPieces[38]->update_coordinates(1, 3);
			board[1][3]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}

void oboard7(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(7, 7);
			board[7][7]=myPieces[0];
			myPieces[1]->update_coordinates(2, 6);
			board[2][6]=myPieces[1];
			myPieces[2]->update_coordinates(2, 8);
			board[2][8]=myPieces[2];
			myPieces[3]->update_coordinates(5, 6);
			board[5][6]=myPieces[3];
			myPieces[4]->update_coordinates(2, 7);
			board[2][7]=myPieces[4];
			myPieces[5]->update_coordinates(3, 9);
			board[3][9]=myPieces[5];
			myPieces[6]->update_coordinates(9, 7);
			board[9][7]=myPieces[6];
			myPieces[7]->update_coordinates(0, 6);
			board[0][6]=myPieces[7];
			myPieces[8]->update_coordinates(3, 7);
			board[3][7]=myPieces[8];
			myPieces[9]->update_coordinates(5, 8);
			board[5][8]=myPieces[9];
			myPieces[10]->update_coordinates(6, 9);
			board[6][9]=myPieces[10];
			myPieces[11]->update_coordinates(3, 8);
			board[3][8]=myPieces[11];
			myPieces[12]->update_coordinates(3, 6);
			board[3][6]=myPieces[12];
			myPieces[13]->update_coordinates(8, 9);
			board[8][9]=myPieces[13];
			myPieces[14]->update_coordinates(8, 6);
			board[8][6]=myPieces[14];
			myPieces[15]->update_coordinates(0, 8);
			board[0][8]=myPieces[15];
			myPieces[16]->update_coordinates(1, 9);
			board[1][9]=myPieces[16];
			myPieces[17]->update_coordinates(5, 9);
			board[5][9]=myPieces[17];
			myPieces[18]->update_coordinates(7, 6);
			board[7][6]=myPieces[18];
			myPieces[19]->update_coordinates(4, 9);
			board[4][9]=myPieces[19];
			myPieces[20]->update_coordinates(6, 7);
			board[6][7]=myPieces[20];
			myPieces[21]->update_coordinates(7, 9);
			board[7][9]=myPieces[21];
			myPieces[22]->update_coordinates(8, 7);
			board[8][7]=myPieces[22];
			myPieces[23]->update_coordinates(9, 8);
			board[9][8]=myPieces[23];
			myPieces[24]->update_coordinates(1, 7);
			board[1][7]=myPieces[24];
			myPieces[25]->update_coordinates(1, 6);
			board[1][6]=myPieces[25];
			myPieces[26]->update_coordinates(4, 7);
			board[4][7]=myPieces[26];
			myPieces[27]->update_coordinates(4, 6);
			board[4][6]=myPieces[27];
			myPieces[28]->update_coordinates(5, 7);
			board[5][7]=myPieces[28];
			myPieces[29]->update_coordinates(6, 6);
			board[6][6]=myPieces[29];
			myPieces[30]->update_coordinates(8, 8);
			board[8][8]=myPieces[30];
			myPieces[31]->update_coordinates(9, 6);
			board[9][6]=myPieces[31];
			myPieces[32]->update_coordinates(6, 8);
			board[6][8]=myPieces[32];
			myPieces[33]->update_coordinates(0, 7);
			board[0][7]=myPieces[33];
			myPieces[34]->update_coordinates(1, 8);
			board[1][8]=myPieces[34];
			myPieces[35]->update_coordinates(2, 9);
			board[2][9]=myPieces[35];
			myPieces[36]->update_coordinates(4, 8);
			board[4][8]=myPieces[36];
			myPieces[37]->update_coordinates(7, 8);
			board[7][8]=myPieces[37];
			myPieces[38]->update_coordinates(9, 9);
			board[9][9]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(7, 2);
			board[7][2]=myPieces[0];
			myPieces[1]->update_coordinates(2, 3);
			board[2][3]=myPieces[1];
			myPieces[2]->update_coordinates(2, 1);
			board[2][1]=myPieces[2];
			myPieces[3]->update_coordinates(5, 3);
			board[5][3]=myPieces[3];
			myPieces[4]->update_coordinates(2, 2);
			board[2][2]=myPieces[4];
			myPieces[5]->update_coordinates(3, 0);
			board[3][0]=myPieces[5];
			myPieces[6]->update_coordinates(9, 2);
			board[9][2]=myPieces[6];
			myPieces[7]->update_coordinates(0, 3);
			board[0][3]=myPieces[7];
			myPieces[8]->update_coordinates(3, 2);
			board[3][2]=myPieces[8];
			myPieces[9]->update_coordinates(5, 1);
			board[5][1]=myPieces[9];
			myPieces[10]->update_coordinates(6, 0);
			board[6][0]=myPieces[10];
			myPieces[11]->update_coordinates(3, 1);
			board[3][1]=myPieces[11];
			myPieces[12]->update_coordinates(3, 3);
			board[3][3]=myPieces[12];
			myPieces[13]->update_coordinates(8, 0);
			board[8][0]=myPieces[13];
			myPieces[14]->update_coordinates(8, 3);
			board[8][3]=myPieces[14];
			myPieces[15]->update_coordinates(0, 1);
			board[0][1]=myPieces[15];
			myPieces[16]->update_coordinates(1, 0);
			board[1][0]=myPieces[16];
			myPieces[17]->update_coordinates(5, 0);
			board[5][0]=myPieces[17];
			myPieces[18]->update_coordinates(7, 3);
			board[7][3]=myPieces[18];
			myPieces[19]->update_coordinates(4, 0);
			board[4][0]=myPieces[19];
			myPieces[20]->update_coordinates(6, 2);
			board[6][2]=myPieces[20];
			myPieces[21]->update_coordinates(7, 0);
			board[7][0]=myPieces[21];
			myPieces[22]->update_coordinates(8, 2);
			board[8][2]=myPieces[22];
			myPieces[23]->update_coordinates(9, 1);
			board[9][1]=myPieces[23];
			myPieces[24]->update_coordinates(1, 2);
			board[1][2]=myPieces[24];
			myPieces[25]->update_coordinates(1, 3);
			board[1][3]=myPieces[25];
			myPieces[26]->update_coordinates(4, 2);
			board[4][2]=myPieces[26];
			myPieces[27]->update_coordinates(4, 3);
			board[4][3]=myPieces[27];
			myPieces[28]->update_coordinates(5, 2);
			board[5][2]=myPieces[28];
			myPieces[29]->update_coordinates(6, 3);
			board[6][3]=myPieces[29];
			myPieces[30]->update_coordinates(8, 1);
			board[8][1]=myPieces[30];
			myPieces[31]->update_coordinates(9, 3);
			board[9][3]=myPieces[31];
			myPieces[32]->update_coordinates(6, 1);
			board[6][1]=myPieces[32];
			myPieces[33]->update_coordinates(0, 2);
			board[0][2]=myPieces[33];
			myPieces[34]->update_coordinates(1, 1);
			board[1][1]=myPieces[34];
			myPieces[35]->update_coordinates(2, 0);
			board[2][0]=myPieces[35];
			myPieces[36]->update_coordinates(4, 1);
			board[4][1]=myPieces[36];
			myPieces[37]->update_coordinates(7, 1);
			board[7][1]=myPieces[37];
			myPieces[38]->update_coordinates(9, 0);
			board[9][0]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}

void oboard8(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(5, 7);
			board[5][7]=myPieces[0];
			myPieces[1]->update_coordinates(1, 6);
			board[1][6]=myPieces[1];
			myPieces[2]->update_coordinates(3, 6);
			board[3][6]=myPieces[2];
			myPieces[3]->update_coordinates(7, 6);
			board[7][6]=myPieces[3];
			myPieces[4]->update_coordinates(4, 7);
			board[4][7]=myPieces[4];
			myPieces[5]->update_coordinates(8, 7);
			board[8][7]=myPieces[5];
			myPieces[6]->update_coordinates(9, 9);
			board[9][9]=myPieces[6];
			myPieces[7]->update_coordinates(3, 7);
			board[3][7]=myPieces[7];
			myPieces[8]->update_coordinates(4, 9);
			board[4][9]=myPieces[8];
			myPieces[9]->update_coordinates(7, 8);
			board[7][8]=myPieces[9];
			myPieces[10]->update_coordinates(9, 8);
			board[9][8]=myPieces[10];
			myPieces[11]->update_coordinates(5, 8);
			board[5][8]=myPieces[11];
			myPieces[12]->update_coordinates(5, 6);
			board[5][6]=myPieces[12];
			myPieces[13]->update_coordinates(8, 9);
			board[8][9]=myPieces[13];
			myPieces[14]->update_coordinates(9, 6);
			board[9][6]=myPieces[14];
			myPieces[15]->update_coordinates(0, 7);
			board[0][7]=myPieces[15];
			myPieces[16]->update_coordinates(1, 8);
			board[1][8]=myPieces[16];
			myPieces[17]->update_coordinates(2, 9);
			board[2][9]=myPieces[17];
			myPieces[18]->update_coordinates(6, 8);
			board[6][8]=myPieces[18];
			myPieces[19]->update_coordinates(2, 7);
			board[2][7]=myPieces[19];
			myPieces[20]->update_coordinates(5, 9);
			board[5][9]=myPieces[20];
			myPieces[21]->update_coordinates(6, 9);
			board[6][9]=myPieces[21];
			myPieces[22]->update_coordinates(6, 6);
			board[6][6]=myPieces[22];
			myPieces[23]->update_coordinates(7, 9);
			board[7][9]=myPieces[23];
			myPieces[24]->update_coordinates(3, 8);
			board[3][8]=myPieces[24];
			myPieces[25]->update_coordinates(4, 8);
			board[4][8]=myPieces[25];
			myPieces[26]->update_coordinates(4, 6);
			board[4][6]=myPieces[26];
			myPieces[27]->update_coordinates(6, 7);
			board[6][7]=myPieces[27];
			myPieces[28]->update_coordinates(7, 7);
			board[7][7]=myPieces[28];
			myPieces[29]->update_coordinates(8, 8);
			board[8][8]=myPieces[29];
			myPieces[30]->update_coordinates(8, 6);
			board[8][6]=myPieces[30];
			myPieces[31]->update_coordinates(9, 7);
			board[9][7]=myPieces[31];
			myPieces[32]->update_coordinates(2, 6);
			board[2][6]=myPieces[32];
			myPieces[33]->update_coordinates(0, 8);
			board[0][8]=myPieces[33];
			myPieces[34]->update_coordinates(1, 9);
			board[1][9]=myPieces[34];
			myPieces[35]->update_coordinates(0, 6);
			board[0][6]=myPieces[35];
			myPieces[36]->update_coordinates(1, 7);
			board[1][7]=myPieces[36];
			myPieces[37]->update_coordinates(2, 8);
			board[2][8]=myPieces[37];
			myPieces[38]->update_coordinates(3, 9);
			board[3][9]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(5, 2);
			board[5][2]=myPieces[0];
			myPieces[1]->update_coordinates(1, 3);
			board[1][3]=myPieces[1];
			myPieces[2]->update_coordinates(3, 3);
			board[3][3]=myPieces[2];
			myPieces[3]->update_coordinates(7, 3);
			board[7][3]=myPieces[3];
			myPieces[4]->update_coordinates(4, 2);
			board[4][2]=myPieces[4];
			myPieces[5]->update_coordinates(8, 2);
			board[8][2]=myPieces[5];
			myPieces[6]->update_coordinates(9, 0);
			board[9][0]=myPieces[6];
			myPieces[7]->update_coordinates(3, 2);
			board[3][2]=myPieces[7];
			myPieces[8]->update_coordinates(4, 0);
			board[4][0]=myPieces[8];
			myPieces[9]->update_coordinates(7, 1);
			board[7][1]=myPieces[9];
			myPieces[10]->update_coordinates(9, 1);
			board[9][1]=myPieces[10];
			myPieces[11]->update_coordinates(5, 1);
			board[5][1]=myPieces[11];
			myPieces[12]->update_coordinates(5, 3);
			board[5][3]=myPieces[12];
			myPieces[13]->update_coordinates(8, 0);
			board[8][0]=myPieces[13];
			myPieces[14]->update_coordinates(9, 3);
			board[9][3]=myPieces[14];
			myPieces[15]->update_coordinates(0, 2);
			board[0][2]=myPieces[15];
			myPieces[16]->update_coordinates(1, 1);
			board[1][1]=myPieces[16];
			myPieces[17]->update_coordinates(2, 0);
			board[2][0]=myPieces[17];
			myPieces[18]->update_coordinates(6, 1);
			board[6][1]=myPieces[18];
			myPieces[19]->update_coordinates(2, 2);
			board[2][2]=myPieces[19];
			myPieces[20]->update_coordinates(5, 0);
			board[5][0]=myPieces[20];
			myPieces[21]->update_coordinates(6, 0);
			board[6][0]=myPieces[21];
			myPieces[22]->update_coordinates(6, 3);
			board[6][3]=myPieces[22];
			myPieces[23]->update_coordinates(7, 0);
			board[7][0]=myPieces[23];
			myPieces[24]->update_coordinates(3, 1);
			board[3][1]=myPieces[24];
			myPieces[25]->update_coordinates(4, 1);
			board[4][1]=myPieces[25];
			myPieces[26]->update_coordinates(4, 3);
			board[4][3]=myPieces[26];
			myPieces[27]->update_coordinates(6, 2);
			board[6][2]=myPieces[27];
			myPieces[28]->update_coordinates(7, 2);
			board[7][2]=myPieces[28];
			myPieces[29]->update_coordinates(8, 1);
			board[8][1]=myPieces[29];
			myPieces[30]->update_coordinates(8, 3);
			board[8][3]=myPieces[30];
			myPieces[31]->update_coordinates(9, 2);
			board[9][2]=myPieces[31];
			myPieces[32]->update_coordinates(2, 3);
			board[2][3]=myPieces[32];
			myPieces[33]->update_coordinates(0, 1);
			board[0][1]=myPieces[33];
			myPieces[34]->update_coordinates(1, 0);
			board[1][0]=myPieces[34];
			myPieces[35]->update_coordinates(0, 3);
			board[0][3]=myPieces[35];
			myPieces[36]->update_coordinates(1, 2);
			board[1][2]=myPieces[36];
			myPieces[37]->update_coordinates(2, 1);
			board[2][1]=myPieces[37];
			myPieces[38]->update_coordinates(3, 0);
			board[3][0]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}

void oboard9(gamePiece **myPieces, gamePiece *board[10][10], bool top, int flipped){
	if(top){
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-7, 7);
			board[flipped-7][7]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 6);
			board[flipped-2][6]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-2, 8);
			board[flipped-2][8]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 8);
			board[flipped-4][8]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-2, 7);
			board[flipped-2][7]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 9);
			board[flipped-3][9]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 7);
			board[flipped-9][7]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 6);
			board[flipped-0][6]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-3, 7);
			board[flipped-3][7]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 8);
			board[flipped-5][8]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 9);
			board[flipped-6][9]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-3, 8);
			board[flipped-3][8]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-3, 6);
			board[flipped-3][6]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 9);
			board[flipped-8][9]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 6);
			board[flipped-8][6]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 8);
			board[flipped-0][8]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 9);
			board[flipped-1][9]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-5, 9);
			board[flipped-5][9]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-7, 6);
			board[flipped-7][6]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 9);
			board[flipped-4][9]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-6, 7);
			board[flipped-6][7]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-7, 9);
			board[flipped-7][9]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 7);
			board[flipped-8][7]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 8);
			board[flipped-9][8]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 7);
			board[flipped-1][7]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 6);
			board[flipped-1][6]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 7);
			board[flipped-4][7]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-7, 8);
			board[flipped-7][8]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-5, 7);
			board[flipped-5][7]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 6);
			board[flipped-6][6]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 8);
			board[flipped-8][8]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 6);
			board[flipped-9][6]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-6, 8);
			board[flipped-6][8]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 7);
			board[flipped-0][7]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 8);
			board[flipped-1][8]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 9);
			board[flipped-2][9]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 6);
			board[flipped-4][6]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-5, 6);
			board[flipped-5][6]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 9);
			board[flipped-9][9]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 9);
			board[flipped-0][9]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(7, 7);
			board[7][7]=myPieces[0];
			myPieces[1]->update_coordinates(2, 6);
			board[2][6]=myPieces[1];
			myPieces[2]->update_coordinates(2, 8);
			board[2][8]=myPieces[2];
			myPieces[3]->update_coordinates(4, 8);
			board[4][8]=myPieces[3];
			myPieces[4]->update_coordinates(2, 7);
			board[2][7]=myPieces[4];
			myPieces[5]->update_coordinates(3, 9);
			board[3][9]=myPieces[5];
			myPieces[6]->update_coordinates(9, 7);
			board[9][7]=myPieces[6];
			myPieces[7]->update_coordinates(0, 6);
			board[0][6]=myPieces[7];
			myPieces[8]->update_coordinates(3, 7);
			board[3][7]=myPieces[8];
			myPieces[9]->update_coordinates(5, 8);
			board[5][8]=myPieces[9];
			myPieces[10]->update_coordinates(6, 9);
			board[6][9]=myPieces[10];
			myPieces[11]->update_coordinates(3, 8);
			board[3][8]=myPieces[11];
			myPieces[12]->update_coordinates(3, 6);
			board[3][6]=myPieces[12];
			myPieces[13]->update_coordinates(8, 9);
			board[8][9]=myPieces[13];
			myPieces[14]->update_coordinates(8, 6);
			board[8][6]=myPieces[14];
			myPieces[15]->update_coordinates(0, 8);
			board[0][8]=myPieces[15];
			myPieces[16]->update_coordinates(1, 9);
			board[1][9]=myPieces[16];
			myPieces[17]->update_coordinates(5, 9);
			board[5][9]=myPieces[17];
			myPieces[18]->update_coordinates(7, 6);
			board[7][6]=myPieces[18];
			myPieces[19]->update_coordinates(4, 9);
			board[4][9]=myPieces[19];
			myPieces[20]->update_coordinates(6, 7);
			board[6][7]=myPieces[20];
			myPieces[21]->update_coordinates(7, 9);
			board[7][9]=myPieces[21];
			myPieces[22]->update_coordinates(8, 7);
			board[8][7]=myPieces[22];
			myPieces[23]->update_coordinates(9, 8);
			board[9][8]=myPieces[23];
			myPieces[24]->update_coordinates(1, 7);
			board[1][7]=myPieces[24];
			myPieces[25]->update_coordinates(1, 6);
			board[1][6]=myPieces[25];
			myPieces[26]->update_coordinates(4, 7);
			board[4][7]=myPieces[26];
			myPieces[27]->update_coordinates(7, 8);
			board[7][8]=myPieces[27];
			myPieces[28]->update_coordinates(5, 7);
			board[5][7]=myPieces[28];
			myPieces[29]->update_coordinates(6, 6);
			board[6][6]=myPieces[29];
			myPieces[30]->update_coordinates(8, 8);
			board[8][8]=myPieces[30];
			myPieces[31]->update_coordinates(9, 6);
			board[9][6]=myPieces[31];
			myPieces[32]->update_coordinates(6, 8);
			board[6][8]=myPieces[32];
			myPieces[33]->update_coordinates(0, 7);
			board[0][7]=myPieces[33];
			myPieces[34]->update_coordinates(1, 8);
			board[1][8]=myPieces[34];
			myPieces[35]->update_coordinates(2, 9);
			board[2][9]=myPieces[35];
			myPieces[36]->update_coordinates(4, 6);
			board[4][6]=myPieces[36];
			myPieces[37]->update_coordinates(5, 6);
			board[5][6]=myPieces[37];
			myPieces[38]->update_coordinates(9, 9);
			board[9][9]=myPieces[38];
			myPieces[39]->update_coordinates(0, 9);
			board[0][9]=myPieces[39];
		}
	}
	else{
		if(flipped==9){
			myPieces[0]->update_coordinates(flipped-7, 2);
			board[flipped-7][2]=myPieces[0];
			myPieces[1]->update_coordinates(flipped-2, 3);
			board[flipped-2][3]=myPieces[1];
			myPieces[2]->update_coordinates(flipped-2, 1);
			board[flipped-2][1]=myPieces[2];
			myPieces[3]->update_coordinates(flipped-4, 1);
			board[flipped-4][1]=myPieces[3];
			myPieces[4]->update_coordinates(flipped-2, 2);
			board[flipped-2][2]=myPieces[4];
			myPieces[5]->update_coordinates(flipped-3, 0);
			board[flipped-3][0]=myPieces[5];
			myPieces[6]->update_coordinates(flipped-9, 2);
			board[flipped-9][2]=myPieces[6];
			myPieces[7]->update_coordinates(flipped-0, 3);
			board[flipped-0][3]=myPieces[7];
			myPieces[8]->update_coordinates(flipped-3, 2);
			board[flipped-3][2]=myPieces[8];
			myPieces[9]->update_coordinates(flipped-5, 1);
			board[flipped-5][1]=myPieces[9];
			myPieces[10]->update_coordinates(flipped-6, 0);
			board[flipped-6][0]=myPieces[10];
			myPieces[11]->update_coordinates(flipped-3, 1);
			board[flipped-3][1]=myPieces[11];
			myPieces[12]->update_coordinates(flipped-3, 3);
			board[flipped-3][3]=myPieces[12];
			myPieces[13]->update_coordinates(flipped-8, 0);
			board[flipped-8][0]=myPieces[13];
			myPieces[14]->update_coordinates(flipped-8, 3);
			board[flipped-8][3]=myPieces[14];
			myPieces[15]->update_coordinates(flipped-0, 1);
			board[flipped-0][1]=myPieces[15];
			myPieces[16]->update_coordinates(flipped-1, 0);
			board[flipped-1][0]=myPieces[16];
			myPieces[17]->update_coordinates(flipped-5, 0);
			board[flipped-5][0]=myPieces[17];
			myPieces[18]->update_coordinates(flipped-7, 3);
			board[flipped-7][3]=myPieces[18];
			myPieces[19]->update_coordinates(flipped-4, 0);
			board[flipped-4][0]=myPieces[19];
			myPieces[20]->update_coordinates(flipped-6, 2);
			board[flipped-6][2]=myPieces[20];
			myPieces[21]->update_coordinates(flipped-7, 0);
			board[flipped-7][0]=myPieces[21];
			myPieces[22]->update_coordinates(flipped-8, 2);
			board[flipped-8][2]=myPieces[22];
			myPieces[23]->update_coordinates(flipped-9, 1);
			board[flipped-9][1]=myPieces[23];
			myPieces[24]->update_coordinates(flipped-1, 2);
			board[flipped-1][2]=myPieces[24];
			myPieces[25]->update_coordinates(flipped-1, 3);
			board[flipped-1][3]=myPieces[25];
			myPieces[26]->update_coordinates(flipped-4, 2);
			board[flipped-4][2]=myPieces[26];
			myPieces[27]->update_coordinates(flipped-7, 1);
			board[flipped-7][1]=myPieces[27];
			myPieces[28]->update_coordinates(flipped-5, 2);
			board[flipped-5][2]=myPieces[28];
			myPieces[29]->update_coordinates(flipped-6, 3);
			board[flipped-6][3]=myPieces[29];
			myPieces[30]->update_coordinates(flipped-8, 1);
			board[flipped-8][1]=myPieces[30];
			myPieces[31]->update_coordinates(flipped-9, 3);
			board[flipped-9][3]=myPieces[31];
			myPieces[32]->update_coordinates(flipped-6, 1);
			board[flipped-6][1]=myPieces[32];
			myPieces[33]->update_coordinates(flipped-0, 2);
			board[flipped-0][2]=myPieces[33];
			myPieces[34]->update_coordinates(flipped-1, 1);
			board[flipped-1][1]=myPieces[34];
			myPieces[35]->update_coordinates(flipped-2, 0);
			board[flipped-2][0]=myPieces[35];
			myPieces[36]->update_coordinates(flipped-4, 3);
			board[flipped-4][3]=myPieces[36];
			myPieces[37]->update_coordinates(flipped-5, 3);
			board[flipped-5][3]=myPieces[37];
			myPieces[38]->update_coordinates(flipped-9, 0);
			board[flipped-9][0]=myPieces[38];
			myPieces[39]->update_coordinates(flipped-0, 0);
			board[flipped-0][0]=myPieces[39];
		}
		else{
			myPieces[0]->update_coordinates(7, 2);
			board[7][2]=myPieces[0];
			myPieces[1]->update_coordinates(2, 3);
			board[2][3]=myPieces[1];
			myPieces[2]->update_coordinates(2, 1);
			board[2][1]=myPieces[2];
			myPieces[3]->update_coordinates(4, 1);
			board[4][1]=myPieces[3];
			myPieces[4]->update_coordinates(2, 2);
			board[2][2]=myPieces[4];
			myPieces[5]->update_coordinates(3, 0);
			board[3][0]=myPieces[5];
			myPieces[6]->update_coordinates(9, 2);
			board[9][2]=myPieces[6];
			myPieces[7]->update_coordinates(0, 3);
			board[0][3]=myPieces[7];
			myPieces[8]->update_coordinates(3, 2);
			board[3][2]=myPieces[8];
			myPieces[9]->update_coordinates(5, 1);
			board[5][1]=myPieces[9];
			myPieces[10]->update_coordinates(6, 0);
			board[6][0]=myPieces[10];
			myPieces[11]->update_coordinates(3, 1);
			board[3][1]=myPieces[11];
			myPieces[12]->update_coordinates(3, 3);
			board[3][3]=myPieces[12];
			myPieces[13]->update_coordinates(8, 0);
			board[8][0]=myPieces[13];
			myPieces[14]->update_coordinates(8, 3);
			board[8][3]=myPieces[14];
			myPieces[15]->update_coordinates(0, 1);
			board[0][1]=myPieces[15];
			myPieces[16]->update_coordinates(1, 0);
			board[1][0]=myPieces[16];
			myPieces[17]->update_coordinates(5, 0);
			board[5][0]=myPieces[17];
			myPieces[18]->update_coordinates(7, 3);
			board[7][3]=myPieces[18];
			myPieces[19]->update_coordinates(4, 0);
			board[4][0]=myPieces[19];
			myPieces[20]->update_coordinates(6, 2);
			board[6][2]=myPieces[20];
			myPieces[21]->update_coordinates(7, 0);
			board[7][0]=myPieces[21];
			myPieces[22]->update_coordinates(8, 2);
			board[8][2]=myPieces[22];
			myPieces[23]->update_coordinates(9, 1);
			board[9][1]=myPieces[23];
			myPieces[24]->update_coordinates(1, 2);
			board[1][2]=myPieces[24];
			myPieces[25]->update_coordinates(1, 3);
			board[1][3]=myPieces[25];
			myPieces[26]->update_coordinates(4, 2);
			board[4][2]=myPieces[26];
			myPieces[27]->update_coordinates(7, 1);
			board[7][1]=myPieces[27];
			myPieces[28]->update_coordinates(5, 2);
			board[5][2]=myPieces[28];
			myPieces[29]->update_coordinates(6, 3);
			board[6][3]=myPieces[29];
			myPieces[30]->update_coordinates(8, 1);
			board[8][1]=myPieces[30];
			myPieces[31]->update_coordinates(9, 3);
			board[9][3]=myPieces[31];
			myPieces[32]->update_coordinates(6, 1);
			board[6][1]=myPieces[32];
			myPieces[33]->update_coordinates(0, 2);
			board[0][2]=myPieces[33];
			myPieces[34]->update_coordinates(1, 1);
			board[1][1]=myPieces[34];
			myPieces[35]->update_coordinates(2, 0);
			board[2][0]=myPieces[35];
			myPieces[36]->update_coordinates(4, 3);
			board[4][3]=myPieces[36];
			myPieces[37]->update_coordinates(5, 3);
			board[5][3]=myPieces[37];
			myPieces[38]->update_coordinates(9, 0);
			board[9][0]=myPieces[38];
			myPieces[39]->update_coordinates(0, 0);
			board[0][0]=myPieces[39];
		}
	}
}




gamePiece ** one_ply_bot::place_pieces(){
	srand ( time(NULL) );
	int flipped = 9*(rand() % 2);
	if(top)
		flipped = 9*(rand() % 2);
	int board_num = rand() % 9 + 1;
	if(top)
		board_num = rand() % 9 + 1;
	if(board_num==1)
		oboard1(myPieces, board, top, flipped);
	else if(board_num==2)
		oboard2(myPieces, board, top, flipped);
	else if(board_num==3)
		oboard3(myPieces, board, top, flipped);
	else if(board_num==4)
		oboard4(myPieces, board, top, flipped);
	else if(board_num==5)
		oboard5(myPieces, board, top, flipped);
	else if(board_num==6)
		oboard6(myPieces, board, top, flipped);
	else if(board_num==7)
		oboard7(myPieces, board, top, flipped);
	else if(board_num==8)
		oboard8(myPieces, board, top, flipped);
	else if(board_num==9)
		oboard9(myPieces, board, top, flipped);
	return myPieces;
}



omoves opossible_moves(gamePiece* piece, gamePiece* board[10][10], int known_values[40], int board_piece_mappings[10][10]){
	omoves poss;
	poss.possible_moves[0][0]=0;
	int num_moves;
	////std::cout<<piece->getX()<<" "<<piece->getY()<<std::endl;
	if(piece->getPieceType()!=Bomb && piece->getPieceType()!=Flag){
		if(piece->getPieceType()!=Scout){
			int x = piece->getX();
			int y = piece->getY();
			if(x!=0 && (board[x-1][y]==NULL || (board[x-1][y]->getPlayerType()==User && ((known_values[board_piece_mappings[x-1][y]] > piece->getPieceType() && known_values[board_piece_mappings[x-1][y]]!=11) || (known_values[board_piece_mappings[x-1][y]]==11 && piece->getPieceType()==8)))) && !((y==4 || y==5) && (x-1 == 2 || x-1 == 3 || x-1 == 6 || x-1 == 7))){
				poss.possible_moves[0][0]++;
				poss.possible_moves[poss.possible_moves[0][0]][0]=x-1;
				poss.possible_moves[poss.possible_moves[0][0]][1]=y;
			}
			if(x!=9 && (board[x+1][y]==NULL || (board[x+1][y]->getPlayerType()==User && ((known_values[board_piece_mappings[x+1][y]] > piece->getPieceType() && known_values[board_piece_mappings[x+1][y]]!=11) || (known_values[board_piece_mappings[x+1][y]]==11 && piece->getPieceType()==8)))) && !((y==4 || y==5) && (x+1 == 2 || x+1 == 3 || x+1 == 6 || x+1 == 7))){
				poss.possible_moves[0][0]++;
				poss.possible_moves[poss.possible_moves[0][0]][0]=x+1;
				poss.possible_moves[poss.possible_moves[0][0]][1]=y;
			}
			if(y!=0 && (board[x][y-1]==NULL || (board[x][y-1]->getPlayerType()==User && ((known_values[board_piece_mappings[x][y-1]] > piece->getPieceType() && known_values[board_piece_mappings[x][y-1]]!=11) || (known_values[board_piece_mappings[x][y-1]]==11 && piece->getPieceType()==8)))) && !((y-1==4 || y-1==5) && (x == 2 || x == 3 || x == 6 || x == 7))){
				poss.possible_moves[0][0]++;
				poss.possible_moves[poss.possible_moves[0][0]][0]=x;
				poss.possible_moves[poss.possible_moves[0][0]][1]=y-1;
			}
			if(y!=9 && (board[x][y+1]==NULL || (board[x][y+1]->getPlayerType()==User && ((known_values[board_piece_mappings[x][y+1]] > piece->getPieceType() && known_values[board_piece_mappings[x][y+1]]!=11) || (known_values[board_piece_mappings[x][y+1]]==11 && piece->getPieceType()==8)))) && !((y+1==4 || y+1==5) && (x == 2 || x == 3 || x == 6 || x == 7))){
				poss.possible_moves[0][0]++;
				poss.possible_moves[poss.possible_moves[0][0]][0]=x;
				poss.possible_moves[poss.possible_moves[0][0]][1]=y+1;
			}
		}
		else{
			int x = piece->getX();
			int y = piece->getY();
			int x_to;
			int y_to;
			for(x_to=x-1; x_to >= 0; x_to--){
				if((board[x_to][y]==NULL || (board[x_to][y]->getPlayerType()==User && known_values[board_piece_mappings[x_to][y]] > piece->getPieceType())) && !((y==4 || y==5) && (x_to == 2 || x_to == 3 || x_to == 6 || x_to == 7))){
					poss.possible_moves[0][0]++;
					poss.possible_moves[poss.possible_moves[0][0]][0]=x_to;
					poss.possible_moves[poss.possible_moves[0][0]][1]=y;
					if(board[x_to][y]!=NULL)
						break;
				}
				else
					break;
			}
			for(x_to=x+1; x_to <= 9; x_to++){
				if((board[x_to][y]==NULL || (board[x_to][y]->getPlayerType()==User && known_values[board_piece_mappings[x_to][y]] > piece->getPieceType())) && !((y==4 || y==5) && (x_to == 2 || x_to == 3 || x_to == 6 || x_to == 7))){
					poss.possible_moves[0][0]++;
					poss.possible_moves[poss.possible_moves[0][0]][0]=x_to;
					poss.possible_moves[poss.possible_moves[0][0]][1]=y;
					if(board[x_to][y]!=NULL)
						break;
				}
				else
					break;
			}
			for(y_to=y-1; y_to >= 0; y_to--){
				if((board[x][y_to]==NULL || (board[x][y_to]->getPlayerType()==User && known_values[board_piece_mappings[x][y_to]] > piece->getPieceType())) && !((y_to==4 || y_to==5) && (x == 2 || x == 3 || x == 6 || x == 7))){
					poss.possible_moves[0][0]++;
					poss.possible_moves[poss.possible_moves[0][0]][0]=x;
					poss.possible_moves[poss.possible_moves[0][0]][1]=y_to;
					if(board[x][y_to]!=NULL)
						break;
				}
				else
					break;
			}
			for(y_to=y+1; y_to <= 9; y_to++){
				if((board[x][y_to]==NULL || (board[x][y_to]->getPlayerType()==User && known_values[board_piece_mappings[x][y_to]] > piece->getPieceType())) && !((y_to==4 || y_to==5) && (x == 2 || x == 3 || x == 6 || x == 7))){
					poss.possible_moves[0][0]++;
					poss.possible_moves[poss.possible_moves[0][0]][0]=x;
					poss.possible_moves[poss.possible_moves[0][0]][1]=y_to;
					if(board[x][y_to]!=NULL)
						break;
				}
				else
					break;
			}
		}
	}
	return poss;
}

float osim_move(int x_from, int y_from, int x_to, int y_to, bool known_copy[40], gamePiece *myPieces_copy[40], gamePiece *opponentPieces_copy[40], int probabilities[40][12][2], gamePiece *board_copy[10][10], int board_piece_mappings_copy[10][10], int known_values[40], int move_count, int pieces_left, bool top){
	int piece_num=-1;
	bool was_known;
	gamePiece *move_piece;
	/*moving*/
	move_piece=board_copy[x_from][y_from];
	if(board_copy[x_to][y_to]==NULL){
		board_copy[x_from][y_from]->update_coordinates(x_to, y_to);
		board_copy[x_to][y_to]=board_copy[x_from][y_from];
		board_copy[x_from][y_from]=NULL;
	}
	else{
		piece_num=board_piece_mappings_copy[x_to][y_to];
		if(known_copy[piece_num]){
			was_known=true;
			board_copy[x_from][y_from]->update_coordinates(x_to, y_to);
			board_copy[x_to][y_to]=board_copy[x_from][y_from];
			board_copy[x_from][y_from]=NULL;
			opponentPieces_copy[piece_num]->update_coordinates(-1, -1);
			board_piece_mappings_copy[x_to][y_to]=-1;
		}
		else{
			was_known=false;
			float prob=0;
			for(int p=1; p<board_copy[x_from][y_from]->getPieceType(); p++){
				if(probabilities[piece_num][p][1]!=0)
					prob+=(probabilities[piece_num][p][0]/probabilities[piece_num][p][1]);
			}
			if(prob<=0.5){
				board_copy[x_from][y_from]->update_coordinates(x_to, y_to);
				board_copy[x_to][y_to]=board_copy[x_from][y_from];
				board_copy[x_from][y_from]=NULL;
				opponentPieces_copy[piece_num]->update_coordinates(-1, -1);
				board_piece_mappings_copy[x_to][y_to]=-1;
			}
			else{
				board_copy[x_from][y_from]->update_coordinates(-1, -1);
				board_copy[x_from][y_from]=NULL;
			}
			known_copy[piece_num]=true;
		}
	}

	float score=oheuristic(known_copy, myPieces_copy, board_copy, opponentPieces_copy, probabilities, move_count, pieces_left, top);

	move_piece->update_coordinates(x_from, y_from);
	board_copy[x_from][y_from]=move_piece;
	if(piece_num!=-1){
		known_copy[piece_num]=was_known;
		opponentPieces_copy[piece_num]->update_coordinates(x_to, y_to);
		board_copy[x_to][y_to]=opponentPieces_copy[piece_num];
		//std::cout<<piece_num<<std::endl;
		board_piece_mappings_copy[x_to][y_to]=piece_num;
	}
	else
		board_copy[x_to][y_to]=NULL;
	return score;
}

void one_ply_bot::make_move(int& x_from, int& y_from, int& x_to, int& y_to){
	x_to = -1;
	y_to = -1;
	x_from = -1;
	y_from = -1;
	float score = -1;
	bool known_copy[40];
	int curr_piece=-1;
	gamePiece *myPieces_copy[40];
	gamePiece *board_copy[10][10];
	gamePiece *opponentPieces_copy[40];
	int board_piece_mappings_copy[10][10];
	for(int x=0; x<10; x++){
		for(int y=0; y<10; y++){
			board_copy[x][y]=NULL;
			board_piece_mappings_copy[x][y]=board_piece_mappings[x][y];
		}
	}
	for(int i=0; i<40; i++){
		known_copy[i]=known[i];
		myPieces_copy[i]=new gamePiece(myPieces[i]->getPieceType(), myPieces[i]->getPlayerType());
		opponentPieces_copy[i]=new gamePiece(opponentPieces[i]->getPieceType(), opponentPieces[i]->getPlayerType());
		myPieces_copy[i]->update_coordinates(myPieces[i]->getX(), myPieces[i]->getY());
		opponentPieces_copy[i]->update_coordinates(opponentPieces[i]->getX(), opponentPieces[i]->getY());
		if(myPieces_copy[i]->getX()>-1)
			board_copy[myPieces_copy[i]->getX()][myPieces_copy[i]->getY()]=myPieces_copy[i];
		if(opponentPieces_copy[i]->getX()>-1)
			board_copy[opponentPieces_copy[i]->getX()][opponentPieces_copy[i]->getY()]=opponentPieces_copy[i];
	}
	for(int i=0; i<40; i++){
		if (myPieces[i]->getX()!=-1){
			omoves poss=opossible_moves(myPieces[i], board, known_values, board_piece_mappings);
			for(int j=1; j<=poss.possible_moves[0][0]; j++){
				int temp_x_from=myPieces[i]->getX();
				int temp_y_from=myPieces[i]->getY();
				int temp_x_to=poss.possible_moves[j][0];
				int temp_y_to=poss.possible_moves[j][1];
				if(all_moves[i][temp_x_to][temp_y_to]<10 || poss.possible_moves[0][0]==1){
					float temp_score = osim_move(temp_x_from, temp_y_from, temp_x_to, temp_y_to, known_copy, myPieces_copy, opponentPieces_copy, probabilities, board_copy, board_piece_mappings_copy, known_values, move_count, pieces_left, top);
					if(temp_score > score){
						score=temp_score;
						x_to=temp_x_to;
						x_from=temp_x_from;
						y_to=temp_y_to;
						y_from=temp_y_from;
						curr_piece=i;
					}
					if(temp_score==score){
						if(!top){
							if (temp_y_to > temp_y_from){
								x_to=temp_x_to;
								x_from=temp_x_from;
								y_to=temp_y_to;
								y_from=temp_y_from;
								curr_piece=i;
							}
						}
						else{
							if (temp_y_to < temp_y_from){
								x_to=temp_x_to;
								x_from=temp_x_from;
								y_to=temp_y_to;
								y_from=temp_y_from;
								curr_piece=i;
							}
						}
					}
				}
			}
		}
	}
	/*deleting*/
	for(int i=0; i<40; i++){
		delete myPieces_copy[i];
		myPieces_copy[i]=0;
		delete opponentPieces_copy[i];
		opponentPieces_copy[i]=0;
	}
	move_count++;
	all_moves[curr_piece][x_to][y_to]++;
	if(y_to==-1){
		int piece;
		omoves poss;
		int move;
		do{
			piece = rand() % 40;
			if(myPieces[piece]->getX()!=-1)
				poss = opossible_moves(myPieces[piece], board, known_values, board_piece_mappings);
		} while (myPieces[piece]->getX()==-1 || poss.possible_moves[0][0]==0);
		move = (rand() % poss.possible_moves[0][0]) + 1;
		x_to=poss.possible_moves[move][0];
		y_to=poss.possible_moves[move][1];
		x_from=myPieces[piece]->getX();
		y_from=myPieces[piece]->getY();
	}
}

void one_ply_bot::update_board(int x_from, int y_from, int x_to, int y_to, int collision_state, piece_type move_piece, piece_type collision_piece){
	if(collision_state==0){
		gamePiece *piece = board[x_from][y_from];
		if(piece->getPlayerType()==User){
			board_piece_mappings[x_to][y_to]=board_piece_mappings[x_from][y_from];
			board_piece_mappings[x_from][y_from]=-1;
			if(!known[board_piece_mappings[x_to][y_to]]){
				if(x_to-x_from>1 || x_to-x_from<-1 || y_to-y_from>1 || y_to-y_from<-1){
					for(int x=0; x<9; x++){
						probabilities[board_piece_mappings[x_to][y_to]][x][0]=0;
					}
					probabilities[board_piece_mappings[x_to][y_to]][9][0]=1;
					probabilities[board_piece_mappings[x_to][y_to]][9][1]=1;
					known[board_piece_mappings[x_to][y_to]]=true;
					known_values[board_piece_mappings[x_to][y_to]]=9;
					probabilities[board_piece_mappings[x_to][y_to]][10][0]=0;
					probabilities[board_piece_mappings[x_to][y_to]][11][0]=0;
					for(int x=0; x<40; x++){
						if(!known[x] && probabilities[x][9][0]!=0){
							for(int y=0; y<12; y++){
								if(probabilities[x][y][1]!=probabilities[x][y][0] && probabilities[x][y][0]!=0){
									probabilities[x][y][1]--;
									if(y==9)
										probabilities[x][y][0]--;
								}
							}
						}
					}
				}
				else{
					if(probabilities[board_piece_mappings[x_to][y_to]][0][0]!=0 || probabilities[board_piece_mappings[x_to][y_to]][11][0]!=0){
						probabilities[board_piece_mappings[x_to][y_to]][0][0]=0;
						probabilities[board_piece_mappings[x_to][y_to]][11][0]=0;
						for(int y=1; y<11; y++){
							if(probabilities[board_piece_mappings[x_to][y_to]][y][1]!=probabilities[board_piece_mappings[x_to][y_to]][y][0] && probabilities[board_piece_mappings[x_to][y_to]][y][0]!=0)
								probabilities[board_piece_mappings[x_to][y_to]][y][1]=probabilities[board_piece_mappings[x_to][y_to]][y][1]-num_left[0]-num_left[11]; // ?
						}
					}
				}
			}
		}
		piece->update_coordinates(x_to, y_to);
		board[x_to][y_to]=piece;
		board[x_from][y_from]=NULL;
	}
	if(collision_state>0)
	{
		gamePiece *piece1 = board[x_from][y_from];
		gamePiece *piece2 = board[x_to][y_to];
		if(piece1->getPlayerType()==User){
			for(int x=0; x<12; x++){
				if(x==move_piece){
					probabilities[board_piece_mappings[x_from][y_from]][x][0]=1;
					probabilities[board_piece_mappings[x_from][y_from]][x][1]=1;
					known[board_piece_mappings[x_from][y_from]]=true;
					known_values[board_piece_mappings[x_from][y_from]]=x;
				}
				else
					probabilities[board_piece_mappings[x_from][y_from]][x][0]=0;
			}
			for(int x=0; x<40; x++){
				if(!known[x] && probabilities[x][move_piece][0]!=0){
					for(int y=0; y<12; y++){
						if(probabilities[x][y][1]!=probabilities[x][y][0] && probabilities[x][y][0]!=0){
							probabilities[x][y][1]--;
							if(y==move_piece)
								probabilities[x][y][0]--;
						}
					}
				}
			}
		}
		else{
			int num=board_piece_mappings[x_to][y_to];
			for(int x=0; x<12; x++){
				if(x==collision_piece){
					probabilities[num][x][0]=1;
					probabilities[num][x][1]=1;
					known[num]=true;
					known_values[num]=x;
				}
				else{
					probabilities[num][x][0]=0;
				}
			}
			for(int x=0; x<40; x++){
				if(!known[x] && probabilities[x][move_piece][0]!=0){
					for(int y=0; y<12; y++){
						if(probabilities[x][y][1]!=probabilities[x][y][0] && probabilities[x][y][0]!=0){
							probabilities[x][y][1]--;
							if(y==collision_piece)
								probabilities[x][y][0]--;
						}
					}
				}
			}
		}
	}
	if(collision_state==1){
		gamePiece *piece1 = board[x_from][y_from];
		gamePiece *piece2 = board[x_to][y_to];
		if(piece1->getPlayerType()==User){
			board_piece_mappings[x_to][y_to]=board_piece_mappings[x_from][y_from];
			board_piece_mappings[x_from][y_from]=-1;
		}
		else{
			board_piece_mappings[x_to][y_to]=-1;
			pieces_left--;
			num_left[collision_piece]--;
		}
		piece2->update_coordinates(-1, -1);
		piece1->update_coordinates(x_to, y_to);
		board[x_to][y_to]=piece1;
		board[x_from][y_from]=NULL;
	}
	else if(collision_state==2){
		gamePiece *piece1 = board[x_from][y_from];
		if(piece1->getPlayerType()==User){
			pieces_left--;
			num_left[move_piece]--;
			board_piece_mappings[x_from][y_from]=-1;
		}
		piece1->update_coordinates(-1, -1);
		board[x_from][y_from]=NULL;
	}
	else if(collision_state==3){
		gamePiece *piece1 = board[x_from][y_from];
		gamePiece *piece2 = board[x_to][y_to];
		if(piece1->getPlayerType()==User){
			board_piece_mappings[x_from][y_from]=-1;
			num_left[move_piece]--;
		}
		else{
			board_piece_mappings[x_to][y_to]=-1;
			num_left[collision_piece]--;
		}
		pieces_left--;
		piece1->update_coordinates(-1, -1);
		piece2->update_coordinates(-1, -1);
		board[x_from][y_from]=NULL;
		board[x_to][y_to]=NULL;
	}
}