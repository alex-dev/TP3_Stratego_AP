#include "gamePiece.h"

gamePiece::gamePiece(piece_type the_type, player_type the_player){
		type = the_type;
		player = the_player;
		if(the_player==User)
			visible=true;
		if(the_player==AI)
			visible=false;
}

gamePiece::~gamePiece(){
}

void gamePiece::update_coordinates(int x, int y){
	x_coord=x;
	y_coord=y;
}

bool gamePiece::isVisible(){
	return visible;
}

player_type gamePiece::getPlayerType(){
	return player;
}

piece_type gamePiece::getPieceType(){
	return type;
}

int gamePiece::getX(){
	return x_coord;
}

int gamePiece::getY(){
	return y_coord;
}

void gamePiece::makeVisible(){
	visible=true;
}

void gamePiece::makeInvisible(){
	visible=false;
}