#ifndef GAMEPIECE_H
#define GAMEPIECE_H

enum piece_type{
	Flag=0,
	Marshal=1,
	General=2,
	Colonel=3,
	Major=4,
	Captain=5,
	Lieutenant=6,
	Sergeant=7,
	Miner=8,
	Scout=9,
	Spy=10,
	Bomb=11,
	Blank=12
};

enum player_type{
	AI=1,
	User=2
};

class gamePiece{
private:
	int x_coord;
	int y_coord;
	piece_type type;
	player_type player;
	bool visible;
public:
	gamePiece(piece_type type, player_type player);
	~gamePiece();
	void update_coordinates(int x_coord, int y_coord);
	player_type gamePiece::getPlayerType();
	piece_type gamePiece::getPieceType();
	bool isVisible();
	void makeVisible();
	void makeInvisible();
	int getX();
	int getY();
};

#endif