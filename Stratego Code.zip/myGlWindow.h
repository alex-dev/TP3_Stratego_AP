#ifndef MYGLWINDOW_H
#define MYGLWINDOW_H

#include "windows.h"
#include "SOIL.h"
#include <math.h>
#include <FL/Gl.H>
#include <Fl/Fl.H>
#include <Fl/Fl_Gl_Window.H>
#include <FL/Fl_Multiline_Output.H>
#include <Fl/Fl_Button.H>
#include <Fl/Fl_Round_Button.H>
#include <FL/Fl_Group.H>
#include <FL/Fl_Check_Button.H>
#include <Gl/glu.h>
#include <stdlib.h>
#include <time.h>
#include "GL/glut.h"
#include "CPU.h"
#include "random_bot.h"
#include "one_ply_bot.h"

class myGlWindow : public Fl_Gl_Window{
private:
    void draw();
	void init();
	bool pushed;
	int mouse_x;
	int mouse_y;
	CPU *computer;
	CPU *computer2;
	random_bot *rand_bot;
	one_ply_bot *one_bot;
	GLuint one;
	GLuint two;
	GLuint three;
	GLuint four;
	GLuint five;
	GLuint six;
	GLuint seven;
	GLuint eight;
	GLuint nine;
	GLuint cactus;
	GLuint bomb;
	GLuint bomb_white;
	GLuint fire;
	GLuint spy;
	GLuint treasure;
	GLuint unknown;
	GLuint one_white;
	GLuint two_white;
	GLuint three_white;
	GLuint four_white;
	GLuint five_white;
	GLuint six_white;
	GLuint seven_white;
	GLuint eight_white;
	GLuint nine_white;
	GLuint cactus_white;
	GLuint spy_white;
	GLuint treasure_white;
	GLuint water;
	GLuint grass;
	GLuint challenger;
	GLuint comp;
	GLuint wins;
	GLuint stalemate;
public:
	bool begin;
	bool started;
	bool game_over;
	int winner;
	int move_count;
	int pieces_down;
	int piece_button;
	int flag_ptr;
	int one_ptr;
	int two_ptr;
	int three_ptr;
	int four_ptr;
	int five_ptr;
	int six_ptr;
	int seven_ptr;
	int eight_ptr;
	int nine_ptr;
	int spy_ptr;
	int bomb_ptr;
	bool player_cpu;
	bool random_cpu;
	bool one_ply_cpu;
	Fl_Multiline_Output *output;
	Fl_Check_Button *setup_board;
	Fl_Group *radio_buttons;
	gamePiece *board[10][10];
	gamePiece *player_pieces[40];
	gamePiece *opponent_pieces[40];
	void random_setup();
	void cpu_move(int player_num);
	void sim_game();
	bool move_piece(player_type p_type, int x_from, int y_from, int x_to, int y_to);
	bool moves_available(bool player);
	void draw_piece(gamePiece *piece);
    myGlWindow(int x, int y, int w, int h, CPU *computer, CPU *computer2, random_bot *rand_bot, one_ply_bot *one_bot);
	~myGlWindow();
	virtual int handle(int e);
};

#endif