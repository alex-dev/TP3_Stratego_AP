#include "gameEngine.h"

int main(int argc, char **argv){
	CPU *computer = new CPU(true);
	CPU *computer2 = new CPU(false);
	random_bot *rand_bot = new random_bot(false);
	one_ply_bot *one_bot = new one_ply_bot(false);
	myGlWindow *g = new myGlWindow(330, 15, 650, 650, computer, computer2, rand_bot, one_bot);
	Fl_Window *w = new Fl_Window(20, 20, 1000, 700);
	gameEngine *engine = new gameEngine(g, w, computer, computer2, rand_bot, one_bot);
	w->add(g);
	w->end();
	w->show();
	g->show();
	Fl::run();
	delete computer;
	computer=0;
	delete computer2;
	computer2=0;
	delete rand_bot;
	rand_bot=0;
	delete one_bot;
	one_bot=0;
	delete engine;
	engine=0;
	delete g;
	g=0;
	delete w;
	w=0;
	return 0;
}