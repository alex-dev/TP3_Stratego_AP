#include <stdlib.h>
#include <iostream>
#include "gameEngine.h"

gameEngine::gameEngine(myGlWindow *g, Fl_Window *w, CPU *computer, CPU *computer2, random_bot *rand_bot, one_ply_bot *one_bot){
	this->g=g;
	this->w=w;
	//w->color(FL_GREEN);
	this->computer = computer;
	this->computer2 = computer2;
	this->rand_bot = rand_bot;
	this->one_bot = one_bot;
	title = new Fl_Box(20,0 ,260,100,"STRATEGO!");
	title->labelsize(40);
    title->labelfont(FL_BOLD+FL_ITALIC);
	setup_board = new Fl_Check_Button(50, 167, 200, 20, "Random Board Setup");
	name = new Fl_Box(25, 35, 260, 100, "By Jeff Petkun and Ju Tan");
	playGame=new Fl_Button(45, 110, 210, 55, "Player vs. Computer");
	playGame->color(FL_RED, FL_MAGENTA);
	computerPlay=new Fl_Button(50, 200, 200, 50, "Computer vs. Computer");
	computerPlay->color(FL_GREEN, FL_CYAN);
	randomPlay=new Fl_Button(50, 250, 200, 50, "Computer vs. Random Bot");
	randomPlay->color(FL_GREEN, FL_CYAN);
	onePlay=new Fl_Button(50, 300, 200, 50, "Computer vs. One Ply Bot");
	onePlay->color(FL_GREEN, FL_CYAN);
	output = new Fl_Multiline_Output(50, 645, 200, 40);
	output->hide();
	Flag_Button = new Fl_Round_Button(50, 370, 200, 25, "Flag: 1 Remaining");
	Flag_Button->type(FL_RADIO_BUTTON);
	Flag_Button->callback((Fl_Callback*)flagCB, this);
	Marshal_Button = new Fl_Round_Button(50, 395, 200, 25, "Marshal (1): 1 Remaining");
	Marshal_Button->type(FL_RADIO_BUTTON);
	Marshal_Button->callback((Fl_Callback*)marshalCB, this);
	General_Button = new Fl_Round_Button(50, 420, 200, 25, "General (2): 1 Remaining");
	General_Button->type(FL_RADIO_BUTTON);
	General_Button->callback((Fl_Callback*)generalCB, this);
	Colonel_Button = new Fl_Round_Button(50, 445, 200, 25, "Colonels (3): 2 Remaining");
	Colonel_Button->type(FL_RADIO_BUTTON);
	Colonel_Button->callback((Fl_Callback*)colonelCB, this);
	Major_Button = new Fl_Round_Button(50, 470, 200, 25, "Majors (4): 3 Remaining");
	Major_Button->type(FL_RADIO_BUTTON);
	Major_Button->callback((Fl_Callback*)majorCB, this);
	Captain_Button = new Fl_Round_Button(50, 495, 200, 25, "Captains (5): 4 Remaining");
	Captain_Button->type(FL_RADIO_BUTTON);
	Captain_Button->callback((Fl_Callback*)captainCB, this);
	Lieutenant_Button = new Fl_Round_Button(50, 520, 200, 25, "Lieutenants (6): 4 Remaining");
	Lieutenant_Button->type(FL_RADIO_BUTTON);
	Lieutenant_Button->callback((Fl_Callback*)lieutenantCB, this);
	Sergeant_Button = new Fl_Round_Button(50, 545, 200, 25, "Sergeants (7): 4 Remaining");
	Sergeant_Button->type(FL_RADIO_BUTTON);
	Sergeant_Button->callback((Fl_Callback*)sergeantCB, this);
	Miner_Button = new Fl_Round_Button(50, 570, 200, 25, "Miners (8): 5 Remaining");
	Miner_Button->type(FL_RADIO_BUTTON);
	Miner_Button->callback((Fl_Callback*)minerCB, this);
	Scout_Button = new Fl_Round_Button(50, 595, 200, 25, "Scouts (9): 8 Remaining");
	Scout_Button->type(FL_RADIO_BUTTON);
	Scout_Button->callback((Fl_Callback*)scoutCB, this);
	Spy_Button = new Fl_Round_Button(50, 620, 200, 25, "Spy: 1 Remaining");
	Spy_Button->type(FL_RADIO_BUTTON);
	Spy_Button->callback((Fl_Callback*)spyCB, this);
	Bomb_Button = new Fl_Round_Button(50, 645, 200, 25, "Bombs: 6 Remaining");
	Bomb_Button->type(FL_RADIO_BUTTON);
	Bomb_Button->callback((Fl_Callback*)bombCB, this);
	Fl_Group *radio_buttons = new Fl_Group(50, 370, 200, 300);
	radio_buttons->add(Flag_Button);
	radio_buttons->add(Marshal_Button);
	radio_buttons->add(General_Button);
	radio_buttons->add(Colonel_Button);
	radio_buttons->add(Major_Button);
	radio_buttons->add(Captain_Button);
	radio_buttons->add(Lieutenant_Button);
	radio_buttons->add(Sergeant_Button);
	radio_buttons->add(Miner_Button);
	radio_buttons->add(Scout_Button);
	radio_buttons->add(Spy_Button);
	radio_buttons->add(Bomb_Button);
	//radio_buttons->color(FL_BLUE);
	playGame->callback((Fl_Callback*)playCB, this);
	computerPlay->callback((Fl_Callback*)computerCB, this);
	randomPlay->callback((Fl_Callback*)randomCB, this);
	onePlay->callback((Fl_Callback*)onePlayCB, this);
	g->output = output;
	g->setup_board = setup_board;
	g->output->value("Please press 'Player vs. \nComputer' or 'Computer\nvs. Computer' to begin");
	g->radio_buttons = radio_buttons;
	int x;
	for(x=0; x<10; x++){
		for(int y=0; y<10; y++)
			g->board[x][y]=NULL;
	}
	g->player_pieces[0]=new gamePiece(Marshal, User);
	g->opponent_pieces[0]=new gamePiece(Marshal, AI);
	g->player_pieces[1]=new gamePiece(General, User);
	g->opponent_pieces[1]=new gamePiece(General, AI);
	for(x=2; x<=3; x++){
		g->player_pieces[x]=new gamePiece(Colonel, User);
		g->opponent_pieces[x]=new gamePiece(Colonel, AI);
	}
	for(x=4; x<=6; x++){
		g->player_pieces[x]=new gamePiece(Major, User);
		g->opponent_pieces[x]=new gamePiece(Major, AI);
	}
	for(x=7; x<=10; x++){
		g->player_pieces[x]=new gamePiece(Captain, User);
		g->opponent_pieces[x]=new gamePiece(Captain, AI);
	}
	for(x=11; x<=14; x++){
		g->player_pieces[x]=new gamePiece(Lieutenant, User);
		g->opponent_pieces[x]=new gamePiece(Lieutenant, AI);
	}
	for(x=15; x<=18; x++){
		g->player_pieces[x]=new gamePiece(Sergeant, User);
		g->opponent_pieces[x]=new gamePiece(Sergeant, AI);
	}
	for(x=19; x<=23; x++){
		g->player_pieces[x]=new gamePiece(Miner, User);
		g->opponent_pieces[x]=new gamePiece(Miner, AI);
	}
	for(x=24; x<=31; x++){
		g->player_pieces[x]=new gamePiece(Scout, User);
		g->opponent_pieces[x]=new gamePiece(Scout, AI);
	}
	g->player_pieces[32]=new gamePiece(Spy, User);
	g->opponent_pieces[32]=new gamePiece(Spy, AI);
	for(x=33; x<=38; x++){
		g->player_pieces[x]=new gamePiece(Bomb, User);
		g->opponent_pieces[x]=new gamePiece(Bomb, AI);
	}
	g->player_pieces[39]=new gamePiece(Flag, User);
	g->opponent_pieces[39]=new gamePiece(Flag, AI);
}

gameEngine::~gameEngine(){
	for(int x=0; x<40; x++){
		delete g->player_pieces[x];
		delete g->opponent_pieces[x];
	}
	delete title;
	title=0;
	delete name;
	name=0;
	delete playGame;
	playGame=0;
	delete computerPlay;
	computerPlay=0;
	delete randomPlay;
	randomPlay=0;
	delete onePlay;
	onePlay=0;
	delete Flag_Button;
	Flag_Button=0;
	delete Marshal_Button;
	Marshal_Button=0;
	delete General_Button;
	General_Button=0;
	delete Colonel_Button;
	Colonel_Button=0;
	delete Major_Button;
	Major_Button= 0;
	delete Captain_Button;
	Captain_Button=0;
	delete Lieutenant_Button;
	Lieutenant_Button=0;
	delete Sergeant_Button;
	Sergeant_Button=0;
	delete Miner_Button;
	Miner_Button=0;
	delete Scout_Button;
	Scout_Button=0;
	delete Spy_Button;
	Spy_Button=0;
	delete Bomb_Button;
	Bomb_Button=0;
	delete setup_board;
	setup_board=0;
}

bool gameEngine::place_player_piece(int index, int x_coord, int y_coord){
	if(g->board[x_coord][y_coord]==NULL && x_coord >=0 && x_coord < 10 && y_coord >= 6 && y_coord < 10){
		g->board[x_coord][y_coord]=g->player_pieces[index];
		g->player_pieces[index]->update_coordinates(x_coord, y_coord);
		g->redraw();
		return true;
	}
	return false;
}

bool gameEngine::place_AI_piece(int index, int x_coord, int y_coord){
	if(g->board[x_coord][y_coord]==NULL && x_coord >=0 && x_coord < 10 && y_coord >= 0 && y_coord < 4){
		g->board[x_coord][y_coord]=g->opponent_pieces[index];
		g->opponent_pieces[index]->update_coordinates(x_coord, y_coord);
		g->redraw();
		return true;
	}
	return false;
}

void playCB(Fl_Button* button, gameEngine* engine){
	engine->g->player_cpu=true;
	engine->g->output->value("Please select a piece to\nplace on the board");
	engine->g->begin=true;
	engine->g->started=false;
	engine->g->move_count=0;
	engine->g->pieces_down=0;
	engine->g->one_ptr=0;
	engine->g->two_ptr=1;
	engine->g->three_ptr=2;
	engine->g->four_ptr=4;
	engine->g->five_ptr=7;
	engine->g->six_ptr=11;
	engine->g->seven_ptr=15;
	engine->g->eight_ptr=19;
	engine->g->nine_ptr=24;
	engine->g->spy_ptr=32;
	engine->g->bomb_ptr=33;
	engine->g->flag_ptr=39;
	engine->g->game_over=false;
	engine->Flag_Button->label("Flag: 1 Remaining");
	engine->Marshal_Button->label("Marshal (1): 1 Remaining");
	engine->General_Button->label("General (2): 1 Remaining");
	engine->Colonel_Button->label("Colonels (3): 2 Remaining");
	engine->Major_Button->label("Majors (4): 3 Remaining");
	engine->Captain_Button->label("Captains (5): 4 Remaining");
	engine->Lieutenant_Button->label("Lieutenants (6): 4 Remaining");
	engine->Sergeant_Button->label("Sergeants (7): 4 Remaining");
	engine->Miner_Button->label("Miners (8): 5 Remaining");
	engine->Scout_Button->label("Scouts(9): 8 Remaining");
	engine->Bomb_Button->label("Bombs: 6 Remaining");
	engine->Spy_Button->label("Spy: 1 Remaining");
	engine->computer->reset();
	for(int x=0; x<10; x++){
		for(int y=0; y<10; y++){
			engine->g->board[x][y]=NULL;
		}
	}
	for(int i=0; i<40; i++){
		engine->g->player_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->makeInvisible();
	}
	gamePiece** pieces = engine->computer->place_pieces();
	int i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 6 && pieces[i]->getY() <= 9){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->opponent_pieces[i];
			engine->g->opponent_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->computer->place_pieces();
			i=0;
		}
	}
	if(engine->setup_board->value()!=0)
		engine->g->random_setup();
	engine->g->redraw();
}

void flagCB(Fl_Round_Button* Flag_Button, gameEngine *engine){
	engine->g->output->value("Please place your flag");
	engine->g->piece_button=0;
}
	
void marshalCB(Fl_Round_Button* Marshal_Button, gameEngine *engine){
	engine->g->output->value("Please place your '1'");
	engine->g->piece_button=1;
}
	
void generalCB(Fl_Round_Button* General_Button, gameEngine *engine){
	engine->g->output->value("Please place your '2'");
	engine->g->piece_button=2;
}
	
void colonelCB(Fl_Round_Button *Colonel_Button, gameEngine *engine){
	engine->g->output->value("Please place a '3'");
	engine->g->piece_button=3;
}
	
void majorCB(Fl_Round_Button *Major_Button, gameEngine *engine){
	engine->g->output->value("Please place a '4'");
	engine->g->piece_button=4;
}
	
void captainCB(Fl_Round_Button *Captain_Button, gameEngine *engine){
	engine->g->output->value("Please place a '5'");
	engine->g->piece_button=5;
}
	
void lieutenantCB(Fl_Round_Button *Lieutenant_Button, gameEngine *engine){
	engine->g->output->value("Please place a '6'");
	engine->g->piece_button=6;
}

void sergeantCB(Fl_Round_Button *Sergeant_Button, gameEngine *engine){
	engine->g->output->value("Please place a '7'");
	engine->g->piece_button=7;
}
	
void minerCB(Fl_Round_Button *Miner_Button, gameEngine *engine){
	engine->g->output->value("Please place an '8'");
	engine->g->piece_button=8;
}
	
void scoutCB(Fl_Round_Button *Scout_Button, gameEngine *engine){
	engine->g->output->value("Please place a '9'");
	engine->g->piece_button=9;
}
	
void spyCB(Fl_Round_Button *Spy_Button, gameEngine *engine){
	engine->g->output->value("Please place your spy");
	engine->g->piece_button=10;
}
	
void bombCB(Fl_Round_Button *Bomb_Button, gameEngine *engine){
	engine->g->output->value("Please place a bomb");
	engine->g->piece_button=11;
}

void computerCB(Fl_Button* computerPlay, gameEngine* engine){
	engine->g->player_cpu=false;
	engine->g->random_cpu=false;
	engine->g->one_ply_cpu=false;
	engine->g->begin=true;
	engine->g->started=false;
	engine->g->pieces_down=0;
	engine->g->move_count=0;
	engine->g->one_ptr=0;
	engine->g->two_ptr=1;
	engine->g->three_ptr=2;
	engine->g->four_ptr=4;
	engine->g->five_ptr=7;
	engine->g->six_ptr=11;
	engine->g->seven_ptr=15;
	engine->g->eight_ptr=19;
	engine->g->nine_ptr=24;
	engine->g->spy_ptr=32;
	engine->g->bomb_ptr=33;
	engine->g->flag_ptr=39;
	engine->g->game_over=false;
	engine->Flag_Button->label("Flag: 1 Remaining");
	engine->Marshal_Button->label("Marshal (1): 1 Remaining");
	engine->General_Button->label("General (2): 1 Remaining");
	engine->Colonel_Button->label("Colonels (3): 2 Remaining");
	engine->Major_Button->label("Majors (4): 3 Remaining");
	engine->Captain_Button->label("Captains (5): 4 Remaining");
	engine->Lieutenant_Button->label("Lieutenants (6): 4 Remaining");
	engine->Sergeant_Button->label("Sergeants (7): 4 Remaining");
	engine->Miner_Button->label("Miners (8): 5 Remaining");
	engine->Scout_Button->label("Scouts (9): 8 Remaining");
	engine->Bomb_Button->label("Bombs: 6 Remaining");
	engine->Spy_Button->label("Spy: 1 Remaining");
	engine->computer->reset();
	engine->computer2->reset();
	for(int x=0; x<10; x++){
		for(int y=0; y<10; y++){
			engine->g->board[x][y]=NULL;
		}
	}
	for(int i=0; i<40; i++){
		engine->g->player_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->makeVisible();
	}
	gamePiece** pieces = engine->computer->place_pieces();
	int i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 6 && pieces[i]->getY() <= 9){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->opponent_pieces[i];
			engine->g->opponent_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->computer->place_pieces();
			i=0;
		}
	}
	pieces = engine->computer2->place_pieces();
	i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 0 && pieces[i]->getY() <= 3){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->player_pieces[i];
			engine->g->player_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->computer2->place_pieces();
			i=0;
		}
	}
	engine->g->sim_game();
}

void randomCB(Fl_Button* randomPlay, gameEngine* engine){
	engine->g->player_cpu=false;
	engine->g->random_cpu=true;
	engine->g->one_ply_cpu=false;
	engine->g->begin=true;
	engine->g->started=false;
	engine->g->pieces_down=0;
	engine->g->move_count=0;
	engine->g->one_ptr=0;
	engine->g->two_ptr=1;
	engine->g->three_ptr=2;
	engine->g->four_ptr=4;
	engine->g->five_ptr=7;
	engine->g->six_ptr=11;
	engine->g->seven_ptr=15;
	engine->g->eight_ptr=19;
	engine->g->nine_ptr=24;
	engine->g->spy_ptr=32;
	engine->g->bomb_ptr=33;
	engine->g->flag_ptr=39;
	engine->g->game_over=false;
	engine->Flag_Button->label("Flag: 1 Remaining");
	engine->Marshal_Button->label("Marshal (1): 1 Remaining");
	engine->General_Button->label("General (2): 1 Remaining");
	engine->Colonel_Button->label("Colonels (3): 2 Remaining");
	engine->Major_Button->label("Majors (4): 3 Remaining");
	engine->Captain_Button->label("Captains (5): 4 Remaining");
	engine->Lieutenant_Button->label("Lieutenants (6): 4 Remaining");
	engine->Sergeant_Button->label("Sergeants (7): 4 Remaining");
	engine->Miner_Button->label("Miners (8): 5 Remaining");
	engine->Scout_Button->label("Scouts (9): 8 Remaining");
	engine->Bomb_Button->label("Bombs: 6 Remaining");
	engine->Spy_Button->label("Spy: 1 Remaining");
	engine->computer->reset();
	engine->rand_bot->reset();
	for(int x=0; x<10; x++){
		for(int y=0; y<10; y++){
			engine->g->board[x][y]=NULL;
		}
	}
	for(int i=0; i<40; i++){
		engine->g->player_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->makeVisible();
	}
	gamePiece** pieces = engine->computer->place_pieces();
	int i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 6 && pieces[i]->getY() <= 9){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->opponent_pieces[i];
			engine->g->opponent_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->computer->place_pieces();
			i=0;
		}
	}
	pieces = engine->rand_bot->place_pieces();
	i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 0 && pieces[i]->getY() <= 3){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->player_pieces[i];
			engine->g->player_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->rand_bot->place_pieces();
			i=0;
		}
	}
	engine->g->sim_game();
}

void onePlayCB(Fl_Button* onePlay, gameEngine* engine){
	engine->g->player_cpu=false;
	engine->g->random_cpu=false;
	engine->g->one_ply_cpu=true;
	engine->g->begin=true;
	engine->g->started=false;
	engine->g->pieces_down=0;
	engine->g->move_count=0;
	engine->g->one_ptr=0;
	engine->g->two_ptr=1;
	engine->g->three_ptr=2;
	engine->g->four_ptr=4;
	engine->g->five_ptr=7;
	engine->g->six_ptr=11;
	engine->g->seven_ptr=15;
	engine->g->eight_ptr=19;
	engine->g->nine_ptr=24;
	engine->g->spy_ptr=32;
	engine->g->bomb_ptr=33;
	engine->g->flag_ptr=39;
	engine->g->game_over=false;
	engine->Flag_Button->label("Flag: 1 Remaining");
	engine->Marshal_Button->label("Marshal (1): 1 Remaining");
	engine->General_Button->label("General (2): 1 Remaining");
	engine->Colonel_Button->label("Colonels (3): 2 Remaining");
	engine->Major_Button->label("Majors (4): 3 Remaining");
	engine->Captain_Button->label("Captains (5): 4 Remaining");
	engine->Lieutenant_Button->label("Lieutenants (6): 4 Remaining");
	engine->Sergeant_Button->label("Sergeants (7): 4 Remaining");
	engine->Miner_Button->label("Miners (8): 5 Remaining");
	engine->Scout_Button->label("Scouts (9): 8 Remaining");
	engine->Bomb_Button->label("Bombs: 6 Remaining");
	engine->Spy_Button->label("Spy: 1 Remaining");
	engine->computer->reset();
	engine->one_bot->reset();
	for(int x=0; x<10; x++){
		for(int y=0; y<10; y++){
			engine->g->board[x][y]=NULL;
		}
	}
	for(int i=0; i<40; i++){
		engine->g->player_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->update_coordinates(-1, -1);
		engine->g->opponent_pieces[i]->makeVisible();
	}
	gamePiece** pieces = engine->computer->place_pieces();
	int i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 6 && pieces[i]->getY() <= 9){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->opponent_pieces[i];
			engine->g->opponent_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->computer->place_pieces();
			i=0;
		}
	}
	pieces = engine->one_bot->place_pieces();
	i=0;
	while(i<40){
		if(engine->g->board[pieces[i]->getX()][pieces[i]->getY()]==NULL && pieces[i]->getX() >= 0 && pieces[i]->getX() <= 9 && pieces[i]->getY() >= 0 && pieces[i]->getY() <= 3){
			engine->g->board[pieces[i]->getX()][pieces[i]->getY()]=engine->g->player_pieces[i];
			engine->g->player_pieces[i]->update_coordinates(pieces[i]->getX(), pieces[i]->getY());
			i++;
		}
		else{
			gamePiece** pieces = engine->one_bot->place_pieces();
			i=0;
		}
	}
	engine->g->sim_game();
}