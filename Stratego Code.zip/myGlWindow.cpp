#include <iostream>
#include <stdlib.h>
#include <time.h>
#include "myGlWindow.h"

void OnSize(int x,int y)
{
	glViewport(0,0,x,y);
	glDrawBuffer(GL_BACK);

	glMatrixMode(GL_PROJECTION);
		glLoadIdentity();
		gluOrtho2D(0,1,1,0);
	glMatrixMode(GL_MODELVIEW);
}

void OnDraw()
{
	glClear(GL_COLOR_BUFFER_BIT);

	glBegin(GL_QUADS);
		glTexCoord2d(0,1);	glVertex2d(0,0);
		glTexCoord2d(1,1);	glVertex2d(1,0);
		glTexCoord2d(1,0);	glVertex2d(1,1);
		glTexCoord2d(0,0);	glVertex2d(0,1);
	glEnd();

	glutSwapBuffers();
}

void draw_image(int x, int y, GLuint object){
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, object);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(50*(x-4.9), 50*(y-4.9));
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(50*(x-4.1), 50*(y-4.9));
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(50*(x-4.1), 50*(y-4.1));
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(50*(x-4.9), 50*(y-4.1));
	glEnd();

	/*glBegin(GL_LINES);
		glVertex2f(50*(x-4.5), 50*(y-4.25));
		glVertex2f(50*(x-4.5), 50*(y-4.75));
	glEnd();
	glBegin(GL_LINES);
		glVertex2f(50*(x-4.5), 50*(y-4.25));
		glVertex2f(50*(x-4.7), 50*(y-4.5));
	glEnd();
	glBegin(GL_LINES);
		glVertex2f(50*(x-4.7), 50*(y-4.75));
		glVertex2f(50*(x-4.3), 50*(y-4.75));
	glEnd();*/
}

void myGlWindow::draw_piece(gamePiece *piece){
	if(!piece->isVisible() && !game_over)
		draw_image(piece->getX(), piece->getY(), unknown);
	else{
		if(piece->getPlayerType()==AI){
			if(piece->getPieceType()==Flag)
				draw_image(piece->getX(), piece->getY(), treasure);
			else if(piece->getPieceType()==Marshal)
				draw_image(piece->getX(), piece->getY(), one);
			else if(piece->getPieceType()==General)
				draw_image(piece->getX(), piece->getY(), two);
			else if(piece->getPieceType()==Colonel)
				draw_image(piece->getX(), piece->getY(), three);
			else if(piece->getPieceType()==Major)
				draw_image(piece->getX(), piece->getY(), four);
			else if(piece->getPieceType()==Captain)
				draw_image(piece->getX(), piece->getY(), five);
			else if(piece->getPieceType()==Lieutenant)
				draw_image(piece->getX(), piece->getY(), six);
			else if(piece->getPieceType()==Sergeant)
				draw_image(piece->getX(), piece->getY(), seven);
			else if(piece->getPieceType()==Miner)
				draw_image(piece->getX(), piece->getY(), eight);
			else if(piece->getPieceType()==Scout)
				draw_image(piece->getX(), piece->getY(), nine);
			else if(piece->getPieceType()==Spy)
				draw_image(piece->getX(), piece->getY(), spy);
			else
				draw_image(piece->getX(), piece->getY(), bomb);
		}
		else{
			if(piece->getPieceType()==Flag)
				draw_image(piece->getX(), piece->getY(), treasure_white);
			else if(piece->getPieceType()==Marshal)
				draw_image(piece->getX(), piece->getY(), one_white);
			else if(piece->getPieceType()==General)
				draw_image(piece->getX(), piece->getY(), two_white);
			else if(piece->getPieceType()==Colonel)
				draw_image(piece->getX(), piece->getY(), three_white);
			else if(piece->getPieceType()==Major)
				draw_image(piece->getX(), piece->getY(), four_white);
			else if(piece->getPieceType()==Captain)
				draw_image(piece->getX(), piece->getY(), five_white);
			else if(piece->getPieceType()==Lieutenant)
				draw_image(piece->getX(), piece->getY(), six_white);
			else if(piece->getPieceType()==Sergeant)
				draw_image(piece->getX(), piece->getY(), seven_white);
			else if(piece->getPieceType()==Miner)
				draw_image(piece->getX(), piece->getY(), eight_white);
			else if(piece->getPieceType()==Scout)
				draw_image(piece->getX(), piece->getY(), nine_white);
			else if(piece->getPieceType()==Spy)
				draw_image(piece->getX(), piece->getY(), spy_white);
			else
				draw_image(piece->getX(), piece->getY(), bomb_white);
		}
	}
}

bool myGlWindow::move_piece(player_type p_type, int x_from, int y_from, int x_to, int y_to){
	if (move_count > 1000){
		output->value("Stalemate");
		game_over=true;
		winner=0;
		return true;
	}
	if(board[x_from][y_from]==NULL){
		std::cout<<"No piece there"<<std::endl;
		return false;
	}
	if(x_to==x_from && y_to==y_from){
		std::cout<<"Moving zero spaces"<<std::endl;
		return false;
	}
	if(x_to < 0 || x_from < 0 || x_to >=10 || x_from >=10 || y_to < 0 || y_from < 0 || y_to >=10 || y_from >=10){
		std::cout<<"Out of bounds"<<std::endl;
		return false;
	}
	if(board[x_from][y_from]->getPlayerType() != p_type){
		std::cout<<"Moving other player's pieces"<<std::endl;
		return false;
	}
	if(board[x_from][y_from]->getPieceType()==Bomb || board[x_from][y_from]->getPieceType()==Flag){
		std::cout<<"Moving a flag or bomb"<<std::endl;
		return false;
	}
	if((y_to==4 || y_to==5) && (x_to == 2 || x_to == 3 || x_to == 6 || x_to == 7)){
		std::cout<<"Moving into a lake"<<std::endl;
		return false;
	}
	if(!((x_from==x_to && (y_from - y_to == 1 || y_from - y_to == -1)) || (y_from==y_to && (x_from - x_to == -1 || x_from - x_to == 1)))){
		if(board[x_from][y_from]->getPieceType()!=Scout){
			std::cout<<"Moving more than one square"<<std::endl;
			return false;
		}
		if(x_from!=x_to && y_from != y_to){
			std::cout<<"Moving diagonal"<<std::endl;
			return false;
		}
		if(x_from!=x_to){
			if((y_to==4 || y_to==5) && (x_from - x_to > 2 || x_from - x_to < -2)){
				std::cout<<"Moving over a lake"<<std::endl;
				return false;
			}
			if(x_to > x_from){
				for(int i=x_from+1; i<x_to; i++){
					if(board[i][y_to]!=NULL){
						std::cout<<"Hopping a piece"<<std::endl;
						return false;
					}
				}
			}
			else{
				for(int i=x_to+1; i<x_from; i++){
					if(board[i][y_to]!=NULL){
						std::cout<<"Hopping a piece"<<std::endl;
						return false;
					}
				}
			}
		}
		if(y_from!=y_to){
			if((x_to==2 || x_to==3 || x_to==6 || x_to == 7) && ((y_from < 4 && y_to > 5) || (y_to < 4 && y_from > 5))){
				std::cout<<"Hopping a lake"<<std::endl;
				return false;
			}
			if(y_to > y_from){
				for(int i=y_from+1; i<y_to; i++){
					if(board[x_to][i]!=NULL){
						std::cout<<"Hopping a piece"<<std::endl;
						return false;
					}
				}
			}
			else{
				for(int i=y_to+1; i<y_from; i++){
					if(board[x_to][i]!=NULL){
						std::cout<<"Hopping a piece"<<std::endl;
						return false;
					}
				}
			}
		}
	}
	if(board[x_to][y_to]!=NULL){
		gamePiece *move_piece = board[x_from][y_from];
		gamePiece *collision_piece = board[x_to][y_to];
		if (move_piece->getPlayerType()==collision_piece->getPlayerType()){
			std::cout<<"Collided with own piece"<<std::endl;
			return false;
		}
		else{
			if (collision_piece->getPieceType()==Flag){
				move_piece->makeVisible();
				move_piece->update_coordinates(x_to, y_to);
				board[x_to][y_to]=move_piece;
				board[x_from][y_from]=NULL;
				if(move_piece->getPlayerType()==AI){
					output->value("CPU Wins");
					winner=2;
				}
				else{
					output->value("Challenger Wins");
					winner=1;
				}
				game_over=true;
				std::cout<<move_count<<std::endl;
				return true;
			}
			else if (collision_piece->getPieceType() == Bomb && move_piece->getPieceType() != 8){
				move_piece->update_coordinates(-1, -1);
				collision_piece->makeVisible();
				board[x_from][y_from]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
				}
			}
			else if(collision_piece->getPieceType() == Spy && move_piece->getPieceType() == 1){
				move_piece->update_coordinates(-1, -1);
				collision_piece->makeVisible();
				board[x_from][y_from]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					
				}
			}
			else if(collision_piece->getPieceType() == 1 && move_piece->getPieceType() == Spy){
				collision_piece->update_coordinates(-1, -1);
				move_piece->makeVisible();
				move_piece->update_coordinates(x_to, y_to);
				board[x_to][y_to]=move_piece;
				board[x_from][y_from]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());	
				}
			}
			else if(collision_piece->getPieceType() > move_piece->getPieceType()){
				collision_piece->update_coordinates(-1, -1);
				move_piece->makeVisible();
				move_piece->update_coordinates(x_to, y_to);
				board[x_to][y_to]=move_piece;
				board[x_from][y_from]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 1, move_piece->getPieceType(), collision_piece->getPieceType());
				}
			}
			else if(collision_piece->getPieceType() < move_piece->getPieceType()){
				move_piece->update_coordinates(-1, -1);
				collision_piece->makeVisible();
				board[x_from][y_from]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 2, move_piece->getPieceType(), collision_piece->getPieceType());	
				}
			}
			else{
				move_piece->update_coordinates(-1, -1);
				collision_piece->update_coordinates(-1, -1);
				board[x_from][y_from]=NULL;
				board[x_to][y_to]=NULL;
				computer->update_board(x_from, y_from, x_to, y_to, 3, move_piece->getPieceType(), collision_piece->getPieceType());
				if(!player_cpu){
					if(random_cpu)
						rand_bot->update_board(x_from, y_from, x_to, y_to, 3, move_piece->getPieceType(), collision_piece->getPieceType());
					else if(one_ply_cpu)
						one_bot->update_board(x_from, y_from, x_to, y_to, 3, move_piece->getPieceType(), collision_piece->getPieceType());
					else
						computer2->update_board(x_from, y_from, x_to, y_to, 3, move_piece->getPieceType(), collision_piece->getPieceType());
				}
			}
			move_count++;
			return true;
		}
	}
	gamePiece *piece=board[x_from][y_from];
	piece->update_coordinates(x_to, y_to);
	board[x_to][y_to]=piece;
	board[x_from][y_from]=NULL;
	computer->update_board(x_from, y_from, x_to, y_to, 0, Blank, Blank);
	if(!player_cpu){
		if(random_cpu)
			rand_bot->update_board(x_from, y_from, x_to, y_to, 0, Blank, Blank);
		else if(one_ply_cpu)
			one_bot->update_board(x_from, y_from, x_to, y_to, 0, Blank, Blank);
		else
			computer2->update_board(x_from, y_from, x_to, y_to, 0, Blank, Blank);
	}
	redraw();
	move_count++;
	return true;
}

void
myGlWindow::draw(){
	if (!valid()){
		init();
		glLoadIdentity();
        glViewport(0, 0, w(), h());
        gluOrtho2D(-250, 250, -250, 250);
        glClearColor(0, 0, 0, 1);
	}
    glClear(GL_COLOR_BUFFER_BIT);
	glColor3f(1, 1, 1);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, grass);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(50*(-5), 50*(-5));
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(50*(5), 50*(-5));
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(50*(5), 50*(5));
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(50*(-5), 50*(5));
	glEnd();
	for(int k=0; k < 10; k++){
		for(int i=0; i < 4; i++){
			/*glColor3f(0, 0.5, 0.4);
			glBegin(GL_QUADS);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();*/
			glColor3f(0, 0, 0);
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-5));
			glEnd();
		}
	}
	for(int k=0; k < 10; k++){
		for(int i=6; i < 10; i++){
			/*glColor3f(0, 0.5, 0.4);
			glBegin(GL_QUADS);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();*/
			glColor3f(0, 0, 0);
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-5));
			glEnd();
		}
	}
	for(int k=0; k < 2; k++){
		for(int i=4; i < 6; i++){
			/*glColor3f(0, 0.5, 0.4);
			glBegin(GL_QUADS);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();*/
			glColor3f(0, 0, 0);
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-5));
			glEnd();
		}
	}
	for(int k=4; k < 6; k++){
		for(int i=4; i < 6; i++){
			glColor3f(0, 0.5, 0.4);
			/*glBegin(GL_QUADS);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();*/
			glColor3f(0, 0, 0);
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-5));
			glEnd();
		}
	}
	for(int k=8; k < 10; k++){
		for(int i=4; i < 6; i++){
			/*glColor3f(0, 0.5, 0.4);
			glBegin(GL_QUADS);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();*/
			glColor3f(0, 0, 0);
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-5));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-5));
				glVertex2f(50*(k-4), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-4), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-4));
			glEnd();
			glBegin(GL_LINES);
				glVertex2f(50*(k-5), 50*(i-4));
				glVertex2f(50*(k-5), 50*(i-5));
			glEnd();
		}
	}
	glColor3f(1, 1, 1);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, water);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(50*(-3), 50*(-1));
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(50*(-1), 50*(-1));
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(50*(-1), 50*(1));
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(50*(-3), 50*(1));
	glEnd();
	glColor3f(1, 1, 1);
	glEnable(GL_TEXTURE_2D);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glBindTexture(GL_TEXTURE_2D, water);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glBegin(GL_QUADS);
		glTexCoord2f(0.0f, 0.0f);
		glVertex2f(50*(1), 50*(-1));
		glTexCoord2f(1.0f, 0.0f);
		glVertex2f(50*(3), 50*(-1));
		glTexCoord2f(1.0f, 1.0f);
		glVertex2f(50*(3), 50*(1));
		glTexCoord2f(0.0f, 1.0f);
		glVertex2f(50*(1), 50*(1));
	glEnd();
	if(game_over && winner!=0){
		if(winner==1){
			glColor3f(1, 1, 1);
			glEnable(GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glBindTexture(GL_TEXTURE_2D, challenger);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f);
				glVertex2f(50*(-3), 50*(-1));
				glTexCoord2f(1.0f, 0.0f);
				glVertex2f(50*(-1), 50*(-1));
				glTexCoord2f(1.0f, 1.0f);
				glVertex2f(50*(-1), 50*(1));
				glTexCoord2f(0.0f, 1.0f);
				glVertex2f(50*(-3), 50*(1));
			glEnd();
		}
		else if(winner==2){
			glColor3f(1, 1, 1);
			glEnable(GL_TEXTURE_2D);
			glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
			glBindTexture(GL_TEXTURE_2D, comp);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
			glBegin(GL_QUADS);
				glTexCoord2f(0.0f, 0.0f);
				glVertex2f(50*(-3), 50*(-1));
				glTexCoord2f(1.0f, 0.0f);
				glVertex2f(50*(-1), 50*(-1));
				glTexCoord2f(1.0f, 1.0f);
				glVertex2f(50*(-1), 50*(1));
				glTexCoord2f(0.0f, 1.0f);
				glVertex2f(50*(-3), 50*(1));
			glEnd();
		}
		glColor3f(1, 1, 1);
		glEnable(GL_TEXTURE_2D);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glBindTexture(GL_TEXTURE_2D, wins);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(50*(1), 50*(-1));
			glTexCoord2f(1.0f, 0.0f);
			glVertex2f(50*(3), 50*(-1));
			glTexCoord2f(1.0f, 1.0f);
			glVertex2f(50*(3), 50*(1));
			glTexCoord2f(0.0f, 1.0f);
			glVertex2f(50*(1), 50*(1));
		glEnd();
	}
	else if(game_over && winner==0){
		glColor3f(1, 1, 1);
		glEnable(GL_TEXTURE_2D);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glBindTexture(GL_TEXTURE_2D, stalemate);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(50*(-3), 50*(-1));
			glTexCoord2f(1.0f, 0.0f);
			glVertex2f(50*(-1), 50*(-1));
			glTexCoord2f(1.0f, 1.0f);
			glVertex2f(50*(-1), 50*(1));
			glTexCoord2f(0.0f, 1.0f);
			glVertex2f(50*(-3), 50*(1));
		glEnd();
		glColor3f(1, 1, 1);
		glEnable(GL_TEXTURE_2D);
		glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
		glBindTexture(GL_TEXTURE_2D, stalemate);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		glBegin(GL_QUADS);
			glTexCoord2f(0.0f, 0.0f);
			glVertex2f(50*(1), 50*(-1));
			glTexCoord2f(1.0f, 0.0f);
			glVertex2f(50*(3), 50*(-1));
			glTexCoord2f(1.0f, 1.0f);
			glVertex2f(50*(3), 50*(1));
			glTexCoord2f(0.0f, 1.0f);
			glVertex2f(50*(1), 50*(1));
		glEnd();
	}

	if(pushed){
			glColor3f(0.8, 0.65, 0);
			glBegin(GL_QUADS);
			glVertex2f(50*(mouse_x-5), 50*(mouse_y-4));
			glVertex2f(50*(mouse_x-4), 50*(mouse_y-4));
			glVertex2f(50*(mouse_x-4), 50*(mouse_y-5));
			glVertex2f(50*(mouse_x-5), 50*(mouse_y-5));
		glEnd();
	}
	for(int x=0; x<40; x++){
		glColor3f(1, 1, 1);
		draw_piece(player_pieces[x]);
		glColor3f(1, 1, 1);
		draw_piece(opponent_pieces[x]);
	}
}

myGlWindow::myGlWindow(int x, int y, int w, int h, CPU *computer, CPU *computer2, random_bot *rand_bot, one_ply_bot *one_bot) : Fl_Gl_Window(x, y, w, h){
	pushed=false;
	game_over=false;
	started=false;
	begin=false;
	pieces_down=0;
	move_count=0;
	winner=0;
	this->computer = computer;
	this->computer2 = computer2;
	this->rand_bot = rand_bot;
	this->one_bot = one_bot;
	piece_button=-1;
	one_ptr=0;
	two_ptr=1;
	three_ptr=2;
	four_ptr=4;
	five_ptr=7;
	six_ptr=11;
	seven_ptr=15;
	eight_ptr=19;
	nine_ptr=24;
	spy_ptr=32;
	bomb_ptr=33;
	flag_ptr=39;
}

myGlWindow::~myGlWindow(){
}

void myGlWindow::init(){
	one = SOIL_load_OGL_texture(
		"1.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	two = SOIL_load_OGL_texture(
		"2.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	three = SOIL_load_OGL_texture(
		"3.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	four = SOIL_load_OGL_texture(
		"4.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	five = SOIL_load_OGL_texture(
		"5.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	six = SOIL_load_OGL_texture(
		"6.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	seven = SOIL_load_OGL_texture(
		"7.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	eight = SOIL_load_OGL_texture(
		"8.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	nine = SOIL_load_OGL_texture(
		"9.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	cactus = SOIL_load_OGL_texture(
		"cactus.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	treasure = SOIL_load_OGL_texture(
		"treasure.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	spy = SOIL_load_OGL_texture(
		"spy.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	water = SOIL_load_OGL_texture(
		"water.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	grass = SOIL_load_OGL_texture(
		"grass.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	bomb = SOIL_load_OGL_texture(
		"bomb.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	bomb_white = SOIL_load_OGL_texture(
		"bomb-white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	one_white = SOIL_load_OGL_texture(
		"1white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	two_white = SOIL_load_OGL_texture(
		"2white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	three_white = SOIL_load_OGL_texture(
		"3white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	four_white = SOIL_load_OGL_texture(
		"4white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	five_white = SOIL_load_OGL_texture(
		"5white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	six_white = SOIL_load_OGL_texture(
		"6white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	seven_white = SOIL_load_OGL_texture(
		"7white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	eight_white = SOIL_load_OGL_texture(
		"8white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	nine_white = SOIL_load_OGL_texture(
		"9white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	cactus_white = SOIL_load_OGL_texture(
		"cactus-white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	treasure_white = SOIL_load_OGL_texture(
		"treasurewhite.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	spy_white = SOIL_load_OGL_texture(
		"spy-white.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	unknown = SOIL_load_OGL_texture(
		"unknown.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	challenger = SOIL_load_OGL_texture(
		"challenger.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	comp = SOIL_load_OGL_texture(
		"computer.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	wins = SOIL_load_OGL_texture(
		"wins.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
	stalemate = SOIL_load_OGL_texture(
		"stalemate.bmp",
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_INVERT_Y | SOIL_FLAG_NTSC_SAFE_RGB | SOIL_FLAG_COMPRESS_TO_DXT
	);
}

void myGlWindow::sim_game(){
	redraw();
	//Sleep(250);
	flush();
	while(!game_over){
		int x_from, y_from, x_to, y_to = -1;
		if(moves_available(0)){
			computer->make_move(x_from, y_from, x_to, y_to);
			move_piece(AI, x_from, y_from, x_to, y_to);
		}
		else{
			output->value("Challenger Wins");
			winner=1;
			game_over=true;
		}
		//Sleep(250);
		flush();
		redraw();
		if(!game_over){
			if(random_cpu){
				if(moves_available(1)){
					rand_bot->make_move(x_from, y_from, x_to, y_to);
					move_piece(User, x_from, y_from, x_to, y_to);
				}
				else{
					output->value("Challenger Loses");
					winner=2;
					game_over=true;
				}
			}
			else if(one_ply_cpu){
				if(moves_available(1)){
					one_bot->make_move(x_from, y_from, x_to, y_to);
					move_piece(User, x_from, y_from, x_to, y_to);
				}
				else{
					output->value("Challenger Loses");
					game_over=true;
					winner=2;
				}
			}
			else{
				if(moves_available(1)){
					computer2->make_move(x_from, y_from, x_to, y_to);
					move_piece(User, x_from, y_from, x_to, y_to);
				}
				else{
					output->value("CPU Wins");
					game_over=true;
					winner=2;
				}
			}
			//Sleep(500);
			flush();
			redraw();
		}
	}
}

bool myGlWindow::moves_available(bool player){
	if(player){
		for(int j=0; j<40; j++){
			if(player_pieces[j]->getX()!=-1 && player_pieces[j]->getPieceType()!=Bomb && player_pieces[j]->getPieceType()!=Flag){
				int x=player_pieces[j]->getX();
				int y=player_pieces[j]->getY();
				if(x-1>=0 && (board[x-1][y] == NULL || board[x-1][y]->getPlayerType()==AI))
					return true;
				if(x+1<=9 && (board[x+1][y] == NULL || board[x+1][y]->getPlayerType()==AI))
					return true;
				if(y-1>=0 && (board[x][y-1] == NULL || board[x][y-1]->getPlayerType()==AI))
					return true;
				if(y+1<=9 && (board[x][y+1] == NULL || board[x][y+1]->getPlayerType()==AI))
					return true;
			}
		}
		return false;
	}
	else{
		for(int j=0; j<40; j++){
			if(opponent_pieces[j]->getX()!=-1 && opponent_pieces[j]->getPieceType()!=Bomb && opponent_pieces[j]->getPieceType()!=Flag){
				int x=opponent_pieces[j]->getX();
				int y=opponent_pieces[j]->getY();
				if(x-1>=0 && (board[x-1][y] == NULL || board[x-1][y]->getPlayerType()==User))
					return true;
				if(x+1<=9 && (board[x+1][y] == NULL || board[x+1][y]->getPlayerType()==User))
					return true;
				if(y-1>=0 && (board[x][y-1] == NULL || board[x][y-1]->getPlayerType()==User))
					return true;
				if(y+1<=9 && (board[x][y+1] == NULL || board[x][y+1]->getPlayerType()==User))
					return true;
			}
		}
		return false;
	}
}

int
myGlWindow::handle(int e){
	if(player_cpu){
	switch(e){
		case FL_FOCUS:
		case FL_UNFOCUS:
			return 1;
		case FL_PUSH:
			Fl::focus(this);
			if(!started && begin){
				if(pushed==true){
					pushed=false;
					if(9-(Fl::event_y()/65) < 4 && board[Fl::event_x()/65][9-(Fl::event_y()/65)]==NULL){
						board[mouse_x][mouse_y]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
						board[Fl::event_x()/65][9-(Fl::event_y()/65)]=board[mouse_x][mouse_y];
						board[mouse_x][mouse_y]=NULL;
					}
				}
				else if(9-(Fl::event_y()/65) < 4 && board[Fl::event_x()/65][9-(Fl::event_y()/65)]==NULL){
					switch(piece_button){
					case 0:
						if(flag_ptr<40){
							player_pieces[flag_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[flag_ptr];
							flag_ptr++;
							pieces_down++;
							radio_buttons->child(0)->label("Flag: 0 Remaining");
						}
						break;
					case 1:
						if(one_ptr<1){
							player_pieces[one_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[one_ptr];
							one_ptr++;
							pieces_down++;
							radio_buttons->child(1)->label("Marshal (1): 0 Remaining");
						}
						break;
					case 2:
						if(two_ptr<2){
							player_pieces[two_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[two_ptr];
							two_ptr++;
							pieces_down++;
							radio_buttons->child(2)->label("General (2): 0 Remaining");
						}
						break;
					case 3:
						if(three_ptr<4){
							player_pieces[three_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[three_ptr];
							if(three_ptr==2)
								radio_buttons->child(3)->label("Colonels (3): 1 Remaining");
							if(three_ptr==3)
								radio_buttons->child(3)->label("Colonels (3): 0 Remaining");
							three_ptr++;
							pieces_down++;
						}
						break;
					case 4:
						if(four_ptr<7){
							player_pieces[four_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[four_ptr];
							if(four_ptr==4)
								radio_buttons->child(4)->label("Majors (4): 2 Remaining");
							if(four_ptr==5)
								radio_buttons->child(4)->label("Majors (4): 1 Remaining");
							if(four_ptr==6)
								radio_buttons->child(4)->label("Majors (4): 0 Remaining");
							four_ptr++;
							pieces_down++;
						}
						break;
					case 5:
						if(five_ptr<11){
							player_pieces[five_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[five_ptr];
							if(five_ptr==7)
								radio_buttons->child(5)->label("Captains (5): 3 Remaining");
							if(five_ptr==8)
								radio_buttons->child(5)->label("Captains (5): 2 Remaining");
							if(five_ptr==9)
								radio_buttons->child(5)->label("Captains (5): 1 Remaining");
							if(five_ptr==10)
								radio_buttons->child(5)->label("Captains (5): 0 Remaining");
							five_ptr++;
							pieces_down++;
						}
						break;
					case 6:
						if(six_ptr<15){
							player_pieces[six_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[six_ptr];
							if(six_ptr==11)
								radio_buttons->child(6)->label("Lieutenants (6): 3 Remaining");
							if(six_ptr==12)
								radio_buttons->child(6)->label("Lieutenants (6): 2 Remaining");
							if(six_ptr==13)
								radio_buttons->child(6)->label("Lieutenants (6): 1 Remaining");
							if(six_ptr==14)
								radio_buttons->child(6)->label("Lieutenants (6): 0 Remaining");
							six_ptr++;
							pieces_down++;
						}
						break;
					case 7:
						if(seven_ptr<19){
							player_pieces[seven_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[seven_ptr];
							if(seven_ptr==15)
								radio_buttons->child(7)->label("Sergeants (7): 3 Remaining");
							if(seven_ptr==16)
								radio_buttons->child(7)->label("Sergeants (7): 2 Remaining");
							if(seven_ptr==17)
								radio_buttons->child(7)->label("Sergeants (7): 1 Remaining");
							if(seven_ptr==18)
								radio_buttons->child(7)->label("Sergeants (7): 0 Remaining");
							seven_ptr++;
							pieces_down++;
						}
						break;
					case 8:
						if(eight_ptr<24){
							player_pieces[eight_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[eight_ptr];
							if(eight_ptr==19)
								radio_buttons->child(8)->label("Miners (8): 4 Remaining");
							if(eight_ptr==20)
								radio_buttons->child(8)->label("Miners (8): 3 Remaining");
							if(eight_ptr==21)
								radio_buttons->child(8)->label("Miners (8): 2 Remaining");
							if(eight_ptr==22)
								radio_buttons->child(8)->label("Miners (8): 1 Remaining");
							if(eight_ptr==23)
								radio_buttons->child(8)->label("Miners (8): 0 Remaining");
							eight_ptr++;
							pieces_down++;
						}
						break;
					case 9:
						if(nine_ptr<32){
							player_pieces[nine_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[nine_ptr];
							if(nine_ptr==24)
								radio_buttons->child(9)->label("Scouts (9): 7 Remaining");
							if(nine_ptr==25)
								radio_buttons->child(9)->label("Scouts (9): 6 Remaining");
							if(nine_ptr==26)
								radio_buttons->child(9)->label("Scouts (9): 5 Remaining");
							if(nine_ptr==27)
								radio_buttons->child(9)->label("Scouts (9): 4 Remaining");
							if(nine_ptr==28)
								radio_buttons->child(9)->label("Scouts (9): 3 Remaining");
							if(nine_ptr==29)
								radio_buttons->child(9)->label("Scouts (9): 2 Remaining");
							if(nine_ptr==30)
								radio_buttons->child(9)->label("Scouts (9): 1 Remaining");
							if(nine_ptr==31)
								radio_buttons->child(9)->label("Scouts (9): 0 Remaining");
							nine_ptr++;
							pieces_down++;
						}
						break;
					case 10:
						if(spy_ptr<33){
							player_pieces[spy_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[spy_ptr];
							radio_buttons->child(10)->label("Spy: 0 Remaining");
							spy_ptr++;
							pieces_down++;
						}
						break;
					case 11:
						if(bomb_ptr<39){
							player_pieces[bomb_ptr]->update_coordinates(Fl::event_x()/65, 9-(Fl::event_y()/65));
							board[Fl::event_x()/65][9-(Fl::event_y()/65)]=player_pieces[bomb_ptr];
							if(bomb_ptr==33)
								radio_buttons->child(11)->label("Bombs: 5 Remaining");
							if(bomb_ptr==34)
								radio_buttons->child(11)->label("Bombs: 4 Remaining");
							if(bomb_ptr==35)
								radio_buttons->child(11)->label("Bombs: 3 Remaining");
							if(bomb_ptr==36)
								radio_buttons->child(11)->label("Bombs: 2 Remaining");
							if(bomb_ptr==37)
								radio_buttons->child(11)->label("Bombs: 1 Remaining");
							if(bomb_ptr==38)
								radio_buttons->child(11)->label("Bombs: 0 Remaining");
							bomb_ptr++;
							pieces_down++;
						}
						break;
					}
					if(pieces_down==40){
						started=true;
						output->value("Please make a move");
					}
				}
				else if(9-(Fl::event_y()/65) < 4 && board[Fl::event_x()/65][9-(Fl::event_y()/65)]!=NULL && pushed==false){
					pushed=true;
					mouse_x=Fl::event_x()/65;
					mouse_y=9-(Fl::event_y()/65);
				}
			}
			else if(started){
				if(!pushed){
					pushed=true;
					mouse_x=Fl::event_x()/65;
					mouse_y=9-(Fl::event_y()/65);
					redraw();
				}
				else{
					pushed=false;
					if(!game_over){
						if(move_piece(User, mouse_x, mouse_y, Fl::event_x()/65, 9-(Fl::event_y()/65))){
							if(!game_over){
								int x_from, y_from, x_to, y_to = -1;
								output->value("Computer making move");
								if(moves_available(0)){
									computer->make_move(x_from, y_from, x_to, y_to);
									move_piece(AI, x_from, y_from, x_to, y_to);
								}
								else{
									output->value("Challenger Wins");
									winner=1;
									game_over=true;
								}
								if(moves_available(1)){
									output->value("Please make a move");
								}
								else{
									output->value("Challenger Loses");
									winner=2;
									game_over=true;
								}
								redraw();
							}
						}
					}
				}
			}
			redraw();
			return 1;
	}
	return Fl_Gl_Window::handle(e);
	}
}

void myGlWindow::random_setup(){
	srand ( time(NULL) );
	for(int i=0; i<40; i++){
		int x_coord=rand() % 10;
		int y_coord=rand() % 4;
		while(board[x_coord][y_coord]!=NULL){
			x_coord=rand() % 10;
			y_coord=rand() % 4;
		}
		player_pieces[i]->update_coordinates(x_coord, y_coord);
		board[x_coord][y_coord]=player_pieces[i];
	}
	started=true;
	output->value("Please make a move");
}