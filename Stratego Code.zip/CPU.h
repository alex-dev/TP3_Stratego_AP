#ifndef CPU_H
#define CPU_H

#include "gamePiece.h"

struct moves
{
  int possible_moves[19][2];
};

struct bomb_move
{
	int move[2];
};


class CPU{
private:
	gamePiece *board[10][10];
	int all_moves[40][10][10];
	gamePiece *myPieces[40];
	gamePiece *opponentPieces[40];
	bool known[40];
	int known_values[40];
	int board_piece_mappings[10][10];
	int probabilities[40][12][2];
	bool top;
	int pieces_left;
	int num_left[12];
	int move_count;
public:
	CPU(bool top);
	~CPU();
	void reset();
	gamePiece ** place_pieces();
	void make_move(int& x_from, int& y_from, int& x_to, int& y_to);
	void update_board(int x_from, int y_from, int x_to, int y_to, int collision_state, piece_type move_piece, piece_type collision_piece);
};

float sim_move(int x_from, int y_from, int x_to, int y_to, bool known_copy[40], gamePiece *myPieces_copy[40], gamePiece *opponentPieces_copy[40], int probabilities[40][12][2], gamePiece *board_copy[10][10], int board_piece_mappings_copy[10][10], int known_values[40], int num_deep, float alpha, float beta, int move_count, int pieces_left, bool top);

#endif