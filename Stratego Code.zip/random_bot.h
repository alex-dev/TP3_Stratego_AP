#ifndef RANDOM_BOT_H
#define RANDOM_BOT_H

#include "gamePiece.h"

struct rmoves
{
  int possible_moves[19][2];
};

class random_bot{
private:
	gamePiece *board[10][10];
	gamePiece *myPieces[40];
	gamePiece *opponentPieces[40];
	bool top;
public:
	random_bot(bool top);
	~random_bot();
	void reset();
	gamePiece ** place_pieces();
	void make_move(int& x_from, int& y_from, int& x_to, int& y_to);
	void update_board(int x_from, int y_from, int x_to, int y_to, int collision_state, piece_type move_piece, piece_type collision_piece);
};

#endif